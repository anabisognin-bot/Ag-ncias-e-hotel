import React, { useState } from 'react';
import { Group, Guest, Room, SystemNotification } from '../types';
import { 
  Users, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  Plus, 
  Eye, 
  Trash2, 
  ShieldAlert, 
  Calendar, 
  Search, 
  Home, 
  Sparkles,
  Layers,
  Baby,
  Activity,
  Heart
} from 'lucide-react';

interface GroupDashboardProps {
  groups: Group[];
  selectedGroupId: string;
  onSelectGroup: (groupId: string) => void;
  onUpdateGroup: (updatedGroup: Group) => void;
  notifications: SystemNotification[];
  onDismissNotification: (notifId: string) => void;
}

export default function GroupDashboard({
  groups,
  selectedGroupId,
  onSelectGroup,
  onUpdateGroup,
  notifications,
  onDismissNotification
}: GroupDashboardProps) {
  const currentGroup = groups.find(g => g.id === selectedGroupId) || groups[0];
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddGuestForm, setShowAddGuestForm] = useState(false);
  const [selectedGuestForDetails, setSelectedGuestForDetails] = useState<Guest | null>(null);

  // Admin Direct Insert Form State
  const [admName, setAdmName] = useState('');
  const [admDoc, setAdmDoc] = useState('');
  const [admAge, setAdmAge] = useState<number | ''>('');
  const [admContact, setAdmContact] = useState('');
  const [admNeedsSpecial, setAdmNeedsSpecial] = useState(false);
  const [admSpecialDetails, setAdmSpecialDetails] = useState('');
  const [admNeedsCrib, setAdmNeedsCrib] = useState(false);
  const [admFood, setAdmFood] = useState('Nenhuma');
  const [admFoodDetails, setAdmFoodDetails] = useState('');

  if (!currentGroup) {
    return <div className="p-8 text-center text-slate-500">Nenhum grupo cadastrado de momento.</div>;
  }

  // Calculate days remaining to check-in
  const calculateDaysRemaining = (checkInDateStr: string) => {
    // Treat "today" as June 16, 2026 based on mock clock / environment
    const today = new Date('2026-06-16T12:00:00');
    const checkInDate = new Date(checkInDateStr + 'T12:00:00');
    const diffTime = checkInDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const daysRemaining = calculateDaysRemaining(currentGroup.checkInDate);

  // Filtered guest list
  const filteredGuests = currentGroup.guests.filter(g => 
    g.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (g.document && g.document.includes(searchQuery))
  );

  // Calculate stats
  const totalGuestsCount = currentGroup.guests.length;
  const missingInfoGuests = currentGroup.guests.filter(g => g.errors.length > 0);
  const lgpdConsentCount = currentGroup.guests.filter(g => g.lgpdConsentGiven).length;
  const assignedRoomsCount = currentGroup.rooms.filter(r => r.guestIds.length > 0).length;

  // Finalize Group action simulation
  const handleToggleGuestConsent = (guestId: string) => {
    const updatedGuests = currentGroup.guests.map(g => {
      if (g.id === guestId) {
        const consent = !g.lgpdConsentGiven;
        const currentErrors = g.errors.filter(e => e !== 'Pendente consentimento LGPD');
        if (!consent) currentErrors.push('Pendente consentimento LGPD');
        return { 
          ...g, 
          lgpdConsentGiven: consent, 
          lgpdConsentDate: consent ? new Date().toISOString() : undefined,
          errors: currentErrors
        };
      }
      return g;
    });

    onUpdateGroup({
      ...currentGroup,
      guests: updatedGuests
    });
  };

  const handleDeleteGuest = (guestId: string) => {
    if (!window.confirm('Deseja realmente remover este hóspede do grupo? Isso apagará seus dados de alocação de quarto.')) {
      return;
    }

    const updatedGuests = currentGroup.guests.filter(g => g.id !== guestId);
    
    // Clean up rooms config
    const updatedRooms = currentGroup.rooms.map(room => {
      if (room.guestIds.includes(guestId)) {
        return {
          ...room,
          guestIds: room.guestIds.filter(id => id !== guestId)
        };
      }
      return room;
    });

    onUpdateGroup({
      ...currentGroup,
      guests: updatedGuests,
      rooms: updatedRooms
    });

    if (selectedGuestForDetails?.id === guestId) {
      setSelectedGuestForDetails(null);
    }
  };

  // Direct Guest Insertion Form Submission
  const handleAddGuestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!admName.trim() || !admAge) return;

    const errors: string[] = [];
    if (!admDoc.trim()) errors.push('Documento não preenchido');
    if (!admContact.trim()) errors.push('Contato não preenchido');
    errors.push('Não associado a nenhum quarto');

    const newGuest: Guest = {
      id: `gst_manual_${Date.now()}`,
      name: admName,
      document: admDoc || '',
      contact: admContact || '',
      age: Number(admAge),
      country: 'Brasil',
      address: '',
      needsSpecialRoom: admNeedsSpecial,
      specialRoomDetails: admNeedsSpecial ? admSpecialDetails : '',
      needsCrib: admNeedsCrib,
      foodRestrictions: admFood,
      foodRestrictionsDetails: admFood !== 'Nenhuma' ? admFoodDetails : '',
      languageHelp: 'Nenhum',
      needsElderlyTechSupport: Number(admAge) >= 65,
      lgpdConsentGiven: true, // admin inputs are assumed with written authorization
      lgpdConsentDate: new Date().toISOString(),
      errors
    };

    onUpdateGroup({
      ...currentGroup,
      guests: [...currentGroup.guests, newGuest]
    });

    // Reset fields
    setAdmName('');
    setAdmDoc('');
    setAdmAge('');
    setAdmContact('');
    setAdmNeedsSpecial(false);
    setAdmSpecialDetails('');
    setAdmNeedsCrib(false);
    setAdmFood('Nenhuma');
    setAdmFoodDetails('');
    setShowAddGuestForm(false);
  };

  return (
    <div className="space-y-6" id="group-dashboard-root">
      
      {/* Group Selector Dropdown Panel & Important Metadata */}
      <div className="bg-white border border-slate-200/80 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4" id="group-selector-card">
        <div className="space-y-1">
          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Grupo sob Gerenciamento</label>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <select
              value={selectedGroupId}
              onChange={(e) => onSelectGroup(e.target.value)}
              className="text-base font-bold text-slate-800 bg-transparent border-0 focus:ring-0 p-0 cursor-pointer outline-none"
            >
              {groups.map(g => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
            </select>
          </div>
          <p className="text-[11px] text-slate-500">
            Parceria: <strong className="text-slate-700">{currentGroup.agencyName}</strong> ⇆ <span className="text-slate-600">{currentGroup.hotelName}</span>
          </p>
        </div>

        {/* Dynamic Countdown Warning System */}
        <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200/60" id="countdown-card">
          <div className={`p-2.5 rounded-lg ${daysRemaining <= 7 ? 'bg-rose-50 text-rose-600 border border-rose-100 animate-pulse' : 'bg-amber-50 text-amber-700 border border-amber-100'}`}>
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-slate-700">Check-in: {currentGroup.checkInDate}</span>
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                daysRemaining <= 7 ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
              }`}>
                {daysRemaining} dias restantes
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {daysRemaining <= 7 
                ? 'CRÍTICO: O Rooming List final deve ser fechado e entregue até 7 dias pré check-in!' 
                : 'Status regular: restam dias para sanar omissões de dados.'}
            </p>
          </div>
        </div>
      </div>

      {/* Critical Countdown Alert Bar when remaining is ultra close */}
      {daysRemaining <= 7 && (
        <div className="bg-rose-50 border-1.5 border-rose-300 p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-rose-900 shadow-sm" id="deadline-urgency-alarm">
          <div className="flex gap-3">
            <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
            <div>
              <h4 className="font-bold text-sm">Gargalo de Prazo: Menos de 7 dias para o check-in!</h4>
              <p className="text-xs text-rose-700 leading-relaxed">
                Este grupo possui prazos estritamente sensíveis. O regulamento comercial de hospitalidade exige a entrega imediata das dietas e quartos PNE para a logística da governança de serviços. Preencha os hóspedes restantes imediatamente!
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Overview Stat Widgets */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4" id="stats-widget-grid">
        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Hóspedes Inscritos</span>
            <span className="text-xl font-bold text-slate-800">{totalGuestsCount}</span>
          </div>
          <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Omissões Sanitárias</span>
            <span className="text-xl font-bold text-rose-600">{missingInfoGuests.length}</span>
          </div>
          <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
            <ShieldAlert className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Termo LGPD Assinado</span>
            <span className="text-xl font-bold text-emerald-600">
              {lgpdConsentCount} <span className="text-xs text-slate-450 font-normal">({Math.round((lgpdConsentCount / (totalGuestsCount || 1)) * 100)}%)</span>
            </span>
          </div>
          <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-bold block uppercase tracking-wider">Quartos de Apoio Ativos</span>
            <span className="text-xl font-bold text-slate-800">{assignedRoomsCount}</span>
          </div>
          <div className="p-2 bg-slate-50 text-slate-600 rounded-lg">
            <Home className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Custom Pending Alerts Drawer explicitly highlighting the missing info feature requested by user */}
      <div className="bg-amber-50/50 border border-amber-200 p-4 rounded-xl text-amber-900" id="missing-info-notifications-feed">
        <h3 className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 text-amber-800 mb-3">
          <AlertTriangle className="w-4 h-4 text-amber-600" />
          Avisos de Omissão de Dados do Grupo (Informações de Hóspedes Faltantes)
        </h3>

        <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
          {currentGroup.guests.filter(g => g.errors.length > 0).length === 0 ? (
            <div className="bg-white/80 border border-dashed border-amber-350 p-4 rounded-lg text-xs text-slate-500 text-center">
              Parabéns! Todos os hóspedes alimentaram as perguntas coringa e concordaram com a LGPD de forma correta.
            </div>
          ) : (
            currentGroup.guests.filter(g => g.errors.length > 0).map(g => (
              <div key={g.id} className="bg-white p-3 rounded-lg border border-amber-200/80 flex items-center justify-between text-xs gap-3">
                <div className="space-y-1">
                  <span className="font-extrabold text-slate-800">{g.name} ({g.age} anos)</span>
                  <div className="flex flex-wrap gap-1.5 mt-0.5">
                    {g.errors.map((err, idx) => (
                      <span key={idx} className="bg-rose-50 text-rose-700 text-[10px] px-2 py-0.5 rounded border border-rose-100 font-medium whitespace-nowrap">
                        • {err}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedGuestForDetails(g)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-1 rounded text-[10px] uppercase font-bold cursor-pointer transition-colors"
                  >
                    Investigar
                  </button>
                  <span className="bg-amber-100 text-amber-800 font-bold text-[9px] px-1.5 py-0.5 rounded">Pendente</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-tables-layout">
        
        {/* Left Side: Guest Listing and filtration */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-4 md:p-6" id="guests-list-card">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm">Lista Secionada de Hóspedes</h3>
              <p className="text-[11px] text-slate-400">Pesquise hóspedes e administre aprovação de dados de saúde.</p>
            </div>
            
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              <div className="relative flex-1 md:flex-initial">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Pesquisar por nome..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full md:w-56 bg-slate-50 border border-slate-250 pl-8 pr-3 py-1.5 text-xs rounded-lg text-slate-800 outline-none"
                />
              </div>
              <button
                onClick={() => setShowAddGuestForm(!showAddGuestForm)}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3 py-2 rounded-lg cursor-pointer flex items-center gap-1 shrink-0"
              >
                <Plus className="w-4 h-4" />
                Adicionar Hóspede
              </button>
            </div>
          </div>

          {/* Quick manual input form for agence/hotel admins */}
          {showAddGuestForm && (
            <form onSubmit={handleAddGuestSubmit} className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3 mb-4" id="manual-guest-add">
              <h4 className="font-bold text-xs text-slate-700 uppercase tracking-wider">Anotação Administrativa na Rooming List</h4>
              <p className="text-[11px] text-slate-400">Caso o hóspede envie os dados por telefone, adicione-o aqui diretamente. Consentimento LGPD é configurado automaticamente.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Nome Completo *"
                  value={admName}
                  onChange={(e) => setAdmName(e.target.value)}
                  className="bg-white border p-2 text-xs rounded-lg text-slate-800 outline-none w-full"
                  required
                />
                <input
                  type="text"
                  placeholder="RG ou CPF *"
                  value={admDoc}
                  onChange={(e) => setAdmDoc(e.target.value)}
                  className="bg-white border p-2 text-xs rounded-lg text-slate-800 outline-none w-full"
                  required
                />
                <input
                  type="number"
                  placeholder="Idade *"
                  value={admAge}
                  onChange={(e) => setAdmAge(e.target.value === '' ? '' : Number(e.target.value))}
                  className="bg-white border p-2 text-xs rounded-lg text-slate-800 outline-none w-full"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input
                  type="tel"
                  placeholder="Celular do titular de contato *"
                  value={admContact}
                  onChange={(e) => setAdmContact(e.target.value)}
                  className="bg-white border p-2 text-xs rounded-lg text-slate-800 outline-none w-full"
                  required
                />
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-xs text-slate-650">
                    <input
                      type="checkbox"
                      id="adm-needs-special"
                      checked={admNeedsSpecial}
                      onChange={(e) => setAdmNeedsSpecial(e.target.checked)}
                    />
                    <label htmlFor="adm-needs-special">Quarto PNE Especial</label>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-650">
                    <input
                      type="checkbox"
                      id="adm-crib"
                      checked={admNeedsCrib}
                      onChange={(e) => setAdmNeedsCrib(e.target.checked)}
                    />
                    <label htmlFor="adm-crib">Requer Berço</label>
                  </div>
                </div>
              </div>

              {admNeedsSpecial && (
                <input
                  type="text"
                  placeholder="Especifique a necessidade. Ex: Cadeira de banho, sem escadas"
                  value={admSpecialDetails}
                  onChange={(e) => setAdmSpecialDetails(e.target.value)}
                  className="bg-white border p-2 text-xs rounded-lg text-slate-800 outline-none w-full"
                />
              )}

              <div className="grid grid-cols-2 gap-3">
                <select
                  value={admFood}
                  onChange={(e) => setAdmFood(e.target.value)}
                  className="bg-white border p-1.5 text-xs rounded-lg text-slate-800"
                >
                  <option value="Nenhuma">Sem restrição alimentar</option>
                  <option value="Vegetariano">Vegetariano</option>
                  <option value="Vegano">Vegano</option>
                  <option value="Sem Glúten">Sem Glúten (Celíaco)</option>
                  <option value="Sem Lactose">Sem Lactose</option>
                  <option value="Outra">Outra Alergia</option>
                </select>
                {admFood !== 'Nenhuma' && (
                  <input
                    type="text"
                    placeholder="Detalhar alimentos perigosos"
                    value={admFoodDetails}
                    onChange={(e) => setAdmFoodDetails(e.target.value)}
                    className="bg-white border p-2 text-xs rounded-lg text-slate-800 outline-none w-full"
                  />
                )}
              </div>

              <div className="flex gap-2">
                <button type="submit" className="bg-emerald-600 text-white font-bold px-3 py-1.5 rounded-lg text-xs cursor-pointer">
                  Salvar Hóspede
                </button>
                <button type="button" onClick={() => setShowAddGuestForm(false)} className="bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs cursor-pointer">
                  Cancelar
                </button>
              </div>
            </form>
          )}

          {/* Core Table List */}
          <div className="overflow-x-auto" id="guests-main-table-container">
            <table className="w-full text-left border-collapse" id="guests-table">
              <thead>
                <tr className="border-b border-slate-200 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5">Hóspede</th>
                  <th className="py-2.5">Omissões de Dados</th>
                  <th className="py-2.5 text-center">Idosa / PCD Support</th>
                  <th className="py-2.5">Status LGPD</th>
                  <th className="py-2.5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {filteredGuests.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-400">
                      Nenhum hóspede coincide com os critérios de busca.
                    </td>
                  </tr>
                ) : (
                  filteredGuests.map(guest => (
                    <tr key={guest.id} className="hover:bg-slate-50/50" id={`table-row-guest-${guest.id}`}>
                      <td className="py-3">
                        <div className="font-bold text-slate-800">{guest.name}</div>
                        <div className="text-[10px] text-slate-450 mt-0.5">
                          {guest.age} anos • {guest.country} {guest.roomId ? `• Quarto ${currentGroup.rooms.find(r => r.id === guest.roomId)?.number}` : '• Sem Quarto'}
                        </div>
                      </td>
                      <td className="py-3">
                        {guest.errors.length === 0 ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-750 font-bold text-[9px] px-2 py-0.5 rounded border border-emerald-100 uppercase">
                            Completo
                          </span>
                        ) : (
                          <div className="flex flex-wrap gap-1 max-w-[200px]">
                            {guest.errors.map((e, idx) => (
                              <span key={idx} className="bg-amber-50 text-amber-800 text-[9px] px-1 rounded block">
                                {e === 'Não associado a nenhum quarto' ? 'Sem Quarto' : e}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="py-3 text-center">
                        <div className="flex justify-center gap-1.5">
                          {guest.needsSpecialRoom && (
                            <span className="text-[10px] bg-indigo-50 border border-indigo-150 text-indigo-700 font-bold px-1.5 py-0.2 rounded" title="Necessita quarto PNE">
                              PNE
                            </span>
                          )}
                          {guest.needsCrib && (
                            <span className="text-[10px] bg-sky-50 border border-sky-150 text-sky-700 font-bold px-1.5 py-0.2 rounded" title="Requer Berço">
                              Crib
                            </span>
                          )}
                          {guest.needsElderlyTechSupport && (
                            <span className="text-[10px] bg-rose-50 border border-rose-150 text-rose-700 font-bold px-1.5 py-0.2 rounded" title="Requer apoio sênior/chave física">
                              Idoso
                            </span>
                          )}
                          {!guest.needsSpecialRoom && !guest.needsCrib && !guest.needsElderlyTechSupport && (
                            <span className="text-slate-350">-</span>
                          )}
                        </div>
                      </td>
                      <td className="py-3">
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleToggleGuestConsent(guest.id)}
                            className={`w-4 h-4 rounded transition-colors cursor-pointer border ${
                              guest.lgpdConsentGiven 
                                ? 'bg-emerald-500 border-emerald-600 text-white flex items-center justify-center' 
                                : 'bg-white border-slate-300'
                            }`}
                            title="Clique para alternar consentimento LGPD manualmente"
                          >
                            {guest.lgpdConsentGiven && '✓'}
                          </button>
                          <span className={`text-[10px] font-semibold ${guest.lgpdConsentGiven ? 'text-emerald-700' : 'text-rose-600'}`}>
                            {guest.lgpdConsentGiven ? 'Consentido' : 'Pendente'}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setSelectedGuestForDetails(guest)}
                            className="p-1 bg-slate-100 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded transition-colors cursor-pointer"
                            title="Visualizar ficha de saúde e proteção completa"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteGuest(guest.id)}
                            className="p-1 bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-500 rounded transition-colors cursor-pointer"
                            title="Remover Hóspede"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Side: Quick Action Panel & Guest Investigator Drilldown */}
        <div className="lg:col-span-4 space-y-6" id="dashboard-detail-sidebar">
          
          {/* Guest Detailed Information (Clinical & Access priorities) */}
          <div className="bg-white border border-slate-200 rounded-xl p-5" id="guest-drilldown-card">
            <h3 className="font-bold text-slate-800 text-sm mb-3">Ficha Unificada do Hóspede (Segurança)</h3>
            
            {selectedGuestForDetails ? (
              <div className="space-y-4 text-xs" id="drilldown-data-sheet">
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 relative">
                  <div className="font-extrabold text-slate-900 text-sm">{selectedGuestForDetails.name}</div>
                  <div className="text-[10px] text-slate-450 mt-0.5">Idade: {selectedGuestForDetails.age} anos • Documento: {selectedGuestForDetails.document || 'PENDENTE'}</div>
                  <span className="absolute top-3 right-3 text-[9px] bg-indigo-500 text-white font-bold px-1.5 py-0.5 rounded-full uppercase">
                    Ref #{selectedGuestForDetails.id.split('_')[1]}
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between border-b border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-medium">Celular Contato:</span>
                    <span className="font-bold text-slate-700">{selectedGuestForDetails.contact || '⚠️ NÃO PREENCHIDO'}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-medium">Endereço:</span>
                    <span className="font-bold text-slate-700 max-w-[150px] text-right truncate" title={selectedGuestForDetails.address}>
                      {selectedGuestForDetails.address || 'Não cadastrado'}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-medium">Acessibilidade:</span>
                    <span className={`font-bold ${selectedGuestForDetails.needsSpecialRoom ? 'text-amber-700' : 'text-slate-600'}`}>
                      {selectedGuestForDetails.needsSpecialRoom ? 'Sim (Quarto PNE)' : 'Nenhum'}
                    </span>
                  </div>
                  {selectedGuestForDetails.needsSpecialRoom && selectedGuestForDetails.specialRoomDetails && (
                    <div className="bg-amber-50 text-amber-800 p-2 rounded text-[10px] leading-relaxed">
                      <strong>Requisitos PNE:</strong> {selectedGuestForDetails.specialRoomDetails}
                    </div>
                  )}

                  <div className="flex justify-between border-b border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-medium">Requer Berço:</span>
                    <span className="font-bold text-slate-700">{selectedGuestForDetails.needsCrib ? '✓ Sim, berço móvel' : 'Não'}</span>
                  </div>

                  <div className="flex justify-between border-b border-slate-100 pb-1.5 animate-pulse">
                    <span className="text-slate-450 font-medium">Dieta / Alérgenos:</span>
                    <span className={`font-bold ${selectedGuestForDetails.foodRestrictions !== 'Nenhuma' ? 'text-violet-700' : 'text-slate-600'}`}>
                      {selectedGuestForDetails.foodRestrictions}
                    </span>
                  </div>
                  {selectedGuestForDetails.foodRestrictions !== 'Nenhuma' && selectedGuestForDetails.foodRestrictionsDetails && (
                    <div className="bg-violet-50 text-violet-850 p-2 rounded text-[10px] leading-relaxed border border-violet-100">
                      <strong>Orientações Culinárias:</strong> {selectedGuestForDetails.foodRestrictionsDetails}
                    </div>
                  )}

                  <div className="flex justify-between border-b border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-medium">Auxílio Idioma:</span>
                    <span className="font-bold text-slate-700">{selectedGuestForDetails.languageHelp}</span>
                  </div>

                  <div className="flex justify-between border-b border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-medium">Apoio Tecnológico:</span>
                    <span className="font-bold text-slate-700">{selectedGuestForDetails.needsElderlyTechSupport ? 'Chave Física / Ficha Manual' : 'Uso de aplicativo'}</span>
                  </div>
                </div>

                {/* LGPD Audit Log detail inside card */}
                <div className="bg-slate-900 text-slate-100 p-3 rounded-lg space-y-1.5">
                  <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                    <CheckCircle className="w-3.5 h-3.5" />
                    Auditoria LGPD Habilitada
                  </div>
                  <p className="text-[10px] text-slate-300 leading-relaxed">
                    <strong>Aceito em:</strong> {selectedGuestForDetails.lgpdConsentGiven && selectedGuestForDetails.lgpdConsentDate ? new Date(selectedGuestForDetails.lgpdConsentDate).toLocaleString('pt-BR') : 'Pendente de aceite'}
                    <br />
                    <strong>Finalidade única:</strong> Suporte médico emergencial e customização de acessibilidade no check-in.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center p-6 bg-slate-50 border border-dashed border-slate-200 rounded-lg text-slate-400 text-xs text-slate-400">
                Selecione o botão de lupa de um hóspede na tabela para auditar detalhes clínicos, LGPD e emergências de saúde.
              </div>
            )}
          </div>

          {/* Quick instructions checklist for hotels / agency */}
          <div className="bg-indigo-900 text-white p-5 rounded-xl shadow-xs space-y-3" id="admin-checklist-card">
            <h3 className="font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 text-indigo-200">
              <Calendar className="w-4 h-4" />
              Tarefas Pendentes do Operador
            </h3>
            <ul className="space-y-2 text-xs text-indigo-100">
              <li className="flex items-start gap-2">
                <input type="checkbox" defaultChecked className="mt-0.5" />
                <span>Criar Link de Acolhimento Seguro</span>
              </li>
              <li className="flex items-start gap-2">
                <input type="checkbox" defaultChecked={totalGuestsCount > 0} className="mt-0.5" />
                <span>Receber cadastros dos hóspedes com perguntas coringa</span>
              </li>
              <li className="flex items-start gap-2">
                <input type="checkbox" defaultChecked={lgpdConsentCount === totalGuestsCount} className="mt-0.5" />
                <span>Garantir consentimento LGPD de todos ({lgpdConsentCount} de {totalGuestsCount})</span>
              </li>
              <li className="flex items-start gap-2">
                <input type="checkbox" defaultChecked={assignedRoomsCount > 0} className="mt-0.5" />
                <span>Preencher Quarto no Mapa Mental e compatibilidades de dietas</span>
              </li>
              <li className="flex items-start gap-2">
                <input type="checkbox" defaultChecked={daysRemaining < 7} className="mt-0.5" />
                <span>Garantir Rooming List final trancado com antecedência de 7 dias do check-in</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
