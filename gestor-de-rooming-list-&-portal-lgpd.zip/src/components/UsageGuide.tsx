import React from 'react';
import { BookOpen, ShieldCheck, Clock, Users, CheckCircle, HelpCircle, AlertTriangle, Key } from 'lucide-react';

export default function UsageGuide() {
  return (
    <div className="space-y-8 bg-slate-50/50 p-1 md:p-6 rounded-2xl" id="usage-guide-container">
      {/* Overview Card */}
      <div className="bg-white border border-slate-100 p-6 rounded-xl shadow-sm" id="guide-intro-card">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
            <BookOpen className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-slate-800">Guia de Uso & Fluxo de Trabalho</h2>
        </div>
        <p className="text-slate-600 leading-relaxed text-sm">
          Este sistema foi desenvolvido especialmente para resolver o maior gargalo entre agências de turismo e hotéis: 
          o preenchimento, organização rápida e segura de planilhas de <strong>Rooming List</strong>. Sob as diretrizes da <strong>LGPD (Lei Geral de Proteção de Dados)</strong>,
          garantimos que dados sensíveis de saúde (alimentação, acessibilidade, suporte) sirvam exclusivamente para a segurança do hóspede e o conforto da hospedagem.
        </p>
      </div>

      {/* Step by Step Timeline */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6" id="guide-steps-grid">
        <div className="bg-white border border-slate-100 p-5 rounded-xl shadow-xs relative" id="guide-step-1">
          <div className="absolute top-4 right-4 text-3xl font-bold text-slate-100">01</div>
          <div className="p-2 bg-amber-50 text-amber-600 rounded-lg w-fit mb-4">
            <Key className="w-5 h-5" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2 text-base">1. Configuração do Grupo</h3>
          <p className="text-slate-500 text-xs leading-relaxed">
            A agência ou hotel cria o grupo no painel administrativo, gerando um <strong>Link de Acesso Único</strong> e uma <strong>Senha de Identificação</strong> segura de 7 dígitos.
          </p>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-xl shadow-xs relative" id="guide-step-2">
          <div className="absolute top-4 right-4 text-3xl font-bold text-slate-100">02</div>
          <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg w-fit mb-4">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2 text-base">2. Preenchimento Acessível</h3>
          <p className="text-slate-500 text-xs leading-relaxed">
            Hóspedes acessam o link público. Menores preenchem normalmente e idosos contam com o <strong>Modo Sênior Acessível</strong>, com leitura de tela inteligente por áudio e fontes grandes.
          </p>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-xl shadow-xs relative" id="guide-step-3">
          <div className="absolute top-4 right-4 text-3xl font-bold text-slate-100">03</div>
          <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg w-fit mb-4">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2 text-base">3. Consentimento LGPD</h3>
          <p className="text-slate-500 text-xs leading-relaxed">
            As respostas coringa sensíveis são explicadas de forma humana ao hóspede, registrando o carimbo de data, finalidade clara e seu aceite explícito em cartório criptográfico fictício.
          </p>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-xl shadow-xs relative" id="guide-step-4">
          <div className="absolute top-4 right-4 text-3xl font-bold text-slate-100">04</div>
          <div className="p-2 bg-rose-50 text-rose-600 rounded-lg w-fit mb-4">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2 text-base">4. Envio Final (7 dias)</h3>
          <p className="text-slate-500 text-xs leading-relaxed">
            Até <strong>7 dias antes do check-in</strong>, o sistema emite avisos urgentes de lacunas de dados e o hotel finaliza o mapa mental de apartamentos compatíveis sem erros de digitação.
          </p>
        </div>
      </div>

      {/* Critical LGPD Framework Table */}
      <div className="bg-white border border-slate-100 rounded-xl shadow-sm overflow-hidden" id="guide-lgpd-framework-card">
        <div className="p-5 border-b border-slate-100 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-sm uppercase tracking-wider">Metodologia e Coleta de Dados Sob a LGPD</h3>
          </div>
          <span className="text-[10px] bg-emerald-500 text-slate-950 font-bold px-2 py-0.5 rounded-full">
            Em conformidade ativa
          </span>
        </div>

        <div className="p-6 space-y-6">
          <p className="text-slate-600 text-xs leading-relaxed">
            A Lei Geral de Proteção de Dados (L. 13.709/18) divide dados em comuns (como nome, endereço) e <strong>dados sensíveis</strong> (como saúde e etnia). 
            Em nosso sistema de rooming list, coletamos informações que se enquadram em dados de saúde e preferências. Veja como mitigamos riscos e justificamos legalmente cada pergunta coringa:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs" id="lgpd-rules-table">
            <div className="bg-slate-50 p-4 rounded-lg flex gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-bold text-slate-800 mb-1">Restrições Alimentares (Dado Sensível)</h4>
                <p className="text-slate-500">
                  <strong>Base Legal:</strong> Salvaguarda da Vida e Integridade Física do Titular (Art. 11, II, "e").
                  <br />
                  <span className="text-amber-700 font-medium">Por que é crucial?</span> Evita sufocamento por anafilaxia e intoxicações alimentares gravíssimas na estadia. O hotel cria jantares individuais preparados na cozinha exclusiva.
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg flex gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-bold text-slate-800 mb-1">Quartos Especiais & PCD (Dado Sensível)</h4>
                <p className="text-slate-500">
                  <strong>Base Legal:</strong> Execução de Contrato de Acolhimento e Acessibilidade Legal (Art. 11, II, "d").
                  <br />
                  <span className="text-amber-700 font-medium">Por que é crucial?</span> Em planos de evacuação contra incêndios, o hotel precisa saber onde PCDs e idosos de mobilidade reduzida estão posicionados para priorizar o salvamento.
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg flex gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-bold text-slate-800 mb-1">Necessidade de Berço / Crianças</h4>
                <p className="text-slate-500">
                  <strong>Base Legal:</strong> Melhor Interesse do Menor (Art. 14, caput, sob consentimento dos responsáveis).
                  <br />
                  <span className="text-amber-700 font-medium">Por que é crucial?</span> Disponibilizar colchões homologados com grades para prevenção de quedas de recém-nascidos.
                </p>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg flex gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <h4 className="font-bold text-slate-800 mb-1">Apoio Tecnológico para Idosos</h4>
                <p className="text-slate-500">
                  <strong>Base Legal:</strong> Princípio da Inclusão e Adequação (Estatuto do Idoso & Art. 6, II da LGPD).
                  <br />
                  <span className="text-amber-700 font-medium">Por que é crucial?</span> Evitar depressão e exclusão social no check-in digital. A equipe é escalada para recebê-los com instruções presenciais simplificadas e chave física em vez de app de celular.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Safety warnings banner */}
      <div className="bg-amber-50 border border-amber-100 p-5 rounded-xl flex gap-3 items-start" id="guide-disclaimer-banner">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-semibold text-amber-900 text-sm mb-1">Apenas para hotéis e agências licenciadas</h4>
          <p className="text-amber-700 text-xs leading-relaxed">
            Toda Rooming list é criptografada e restrita a links dinâmicos e chaves temporárias expirando em 30 dias após o encerramento do grupo. 
            É proibido extrair relatórios em cópias físicas que contenham restrições alimentares específicas sem que o hotel possua lixeira biológica e triturador de papel em conformidade com o regulamento nacional da ANPD.
          </p>
        </div>
      </div>
    </div>
  );
}
