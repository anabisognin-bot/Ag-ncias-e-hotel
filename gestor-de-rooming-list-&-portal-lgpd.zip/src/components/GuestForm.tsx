import React, { useState, useEffect } from 'react';
import { Guest } from '../types';
import { 
  User, 
  FileText, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  Accessibility, 
  Baby, 
  Utensils, 
  Volume2, 
  VolumeX, 
  Languages, 
  AlertCircle, 
  Sparkles,
  ArrowLeft,
  ArrowRight,
  Eye,
  CheckCircle2
} from 'lucide-react';

interface GuestFormProps {
  initialGroupCode?: string;
  initialGroupPassword?: string;
  onGuestRegistered: (newGuest: Guest) => void;
  availableGroupAccessCodes: { code: string; name: string }[];
}

export default function GuestForm({ 
  initialGroupCode = '', 
  initialGroupPassword = '', 
  onGuestRegistered,
  availableGroupAccessCodes
}: GuestFormProps) {
  // Authentication & Group linkage
  const [accessCode, setAccessCode] = useState(initialGroupCode);
  const [password, setPassword] = useState(initialGroupPassword);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeGroupName, setActiveGroupName] = useState('');

  // Mode configurations
  const [isSeniorMode, setIsSeniorMode] = useState(false);
  const [isHighContrast, setIsHighContrast] = useState(false);
  
  // Wizard step (for senior mode)
  const [seniorStep, setSeniorStep] = useState(1);

  // Audio synthesis state
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [document, setDocument] = useState('');
  const [contact, setContact] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [country, setCountry] = useState('Brasil');
  const [address, setAddress] = useState('');
  const [needsSpecialRoom, setNeedsSpecialRoom] = useState(false);
  const [specialRoomDetails, setSpecialRoomDetails] = useState('');
  const [needsCrib, setNeedsCrib] = useState(false);
  const [foodRestrictions, setFoodRestrictions] = useState('Nenhuma');
  const [foodRestrictionsDetails, setFoodRestrictionsDetails] = useState('');
  const [languageHelp, setLanguageHelp] = useState('Nenhum');
  const [needsElderlyTechSupport, setNeedsElderlyTechSupport] = useState(false);
  const [lgpdConsentGiven, setLgpdConsentGiven] = useState(false);
  const [showLGPDDetailPanel, setShowLGPDDetailPanel] = useState(false);

  // Form error or success states
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);
  const [savedConsentLog, setSavedConsentLog] = useState<any | null>(null);

  useEffect(() => {
    if ('speechSynthesis' in window) {
      setSpeechSupported(true);
    }
  }, []);

  // Stop reading if component unmounts or mode changes
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Speak field instruction
  const handleSpeakText = (textToSpeak: string) => {
    if (!speechSupported) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = 'pt-BR';
    utterance.rate = 0.85; // slightly slower for elderly clarity
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  // Group Password Validation
  const handleAuthenticate = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!accessCode) {
      setFormError('Por favor, selecione ou insira o código de acesso do grupo.');
      return;
    }

    if (!password.trim()) {
      setFormError('Por favor, digite a senha fornecida pela sua agência de viagem.');
      return;
    }

    // Checking code & password combination simulation
    if (accessCode === 'imp-vento-001' && password === 'canela2026') {
      setIsAuthenticated(true);
      setActiveGroupName('Excursão Melhor Idade - Gramado & Canela');
    } else if (accessCode === 'gt-sec-002' && password === 'cybersecret') {
      setIsAuthenticated(true);
      setActiveGroupName('Grupo Executivo TI Segura - CyberSecurity');
    } else {
      setFormError('Senha de segurança inválida para este grupo. Revise em seu bilhete de viagem ou contate o guia.');
    }
  };

  // Form Submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!name.trim()) {
      setFormError('Por favor, informe seu Nome Completo.');
      return;
    }
    if (!age || Number(age) <= 0) {
      setFormError('Por favor, insira uma idade válida.');
      return;
    }
    if (!lgpdConsentGiven) {
      setFormError('Para concluir o cadastro na hospedagem de forma segura com o hotel, você precisa ler e aceitar o Termo de Consentimento LGPD.');
      return;
    }

    // Calculate issues/errors
    const errors: string[] = [];
    if (!document.trim()) errors.push('Documento não preenchido');
    if (!contact.trim()) errors.push('Contato não preenchido');
    if (foodRestrictions !== 'Nenhuma' && !foodRestrictionsDetails.trim()) {
      errors.push('Detalhes da restrição alimentar não especificados');
    }

    const newGuest: Guest = {
      id: `gst_${Date.now()}`,
      name,
      document: document || '',
      contact: contact || '',
      age: Number(age),
      country,
      address: address || '',
      needsSpecialRoom,
      specialRoomDetails: needsSpecialRoom ? specialRoomDetails : '',
      needsCrib,
      foodRestrictions,
      foodRestrictionsDetails: foodRestrictions !== 'Nenhuma' ? foodRestrictionsDetails : '',
      languageHelp,
      needsElderlyTechSupport: needsElderlyTechSupport || Number(age) >= 65,
      lgpdConsentGiven,
      lgpdConsentDate: new Date().toISOString(),
      errors
    };

    // Store a mock audit log for LGPD review
    const consentLog = {
      timestamp: new Date().toLocaleDateString('pt-BR') + ' às ' + new Date().toLocaleTimeString('pt-BR'),
      hash: 'SHA256-' + Math.random().toString(36).substring(4).toUpperCase(),
      purpose: 'Segurança Alimentar, Acessibilidade PNE & Emergências de Saúde Coletiva',
      ip: '192.168.1.' + Math.floor(Math.random() * 254 + 1),
      agencia: activeGroupName,
    };

    setSavedConsentLog(consentLog);
    onGuestRegistered(newGuest);
    setFormSuccess(true);
    
    // Read success message to seniors
    if (isSeniorMode && speechSupported) {
      handleSpeakText(`Parabéns ${name}! Seu formulário de hospedagem foi enviado com sucesso sob proteção de dados. Desejamos uma excelente viagem!`);
    }
  };

  // Skip step helper for seniors
  const nextSeniorStep = () => {
    if (isSpeaking) window.speechSynthesis.cancel();
    setSeniorStep(prev => Math.min(prev + 1, 4));
  };

  const prevSeniorStep = () => {
    if (isSpeaking) window.speechSynthesis.cancel();
    setSeniorStep(prev => Math.max(prev - 1, 1));
  };

  const currentThemeClasses = () => {
    if (isHighContrast) {
      return 'bg-white text-black border-4 border-black p-6 md:p-8 rounded-none';
    }
    return 'bg-white text-slate-800 border border-slate-200/80 p-6 md:p-8 rounded-2xl shadow-sm';
  };

  const inputClasses = () => {
    if (isHighContrast) {
      return 'w-full bg-white text-black border-3 border-black p-3 text-lg font-bold outline-none focus:bg-amber-100';
    }
    if (isSeniorMode) {
      return 'w-full bg-slate-50 border border-slate-300 p-3 text-base rounded-xl text-slate-900 focus:ring-2 focus:ring-indigo-500/20';
    }
    return 'w-full bg-slate-50 border border-slate-200 p-2 text-xs rounded-lg text-slate-900 focus:ring-1 focus:ring-indigo-500';
  };

  const labelClasses = () => {
    if (isHighContrast) {
      return 'block text-lg font-extrabold text-black mb-1.5 uppercase';
    }
    if (isSeniorMode) {
      return 'block text-base font-bold text-slate-700 mb-1.5';
    }
    return 'block text-xs font-semibold text-slate-600 mb-1';
  };

  // Helper text arrays for voice instructions
  const audioPrompts = {
    step1: "Olá! Seja bem-vindo à ficha de cadastro da viagem. Digite primeiro seu Nome Completo, seu documento como RG ou CPF, e a sua Idade.",
    step2: "Agora, digite seu telefone ou celular com o código de área, o país onde você vive, e o seu endereço residencial completo.",
    step3: "No passo três, diga se você tem alguma necessidade de quarto especial com barras ou acessível, se precisa de berço para bebês, e se possui qualquer restrição alimentar como intolerância a glúten ou lactose.",
    step4: "No último passo, indique se precisa de ajuda com tecnologia por ser idoso, e clique no termo de consentimento da LGPD para mantermos seus dados de saúde protegidos."
  };

  return (
    <div className="space-y-6" id="guest-form-container">
      {/* Top Banner Options */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-indigo-50 p-4 rounded-xl border border-indigo-100" id="form-modes-bar">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
          <div>
            <span className="font-bold text-xs text-indigo-900 block">Modo de Exibição do Titular</span>
            <span className="text-[10px] text-indigo-700 leading-tight block">Inclusão digital: mude para o modo idoso para facilitar o teclado e ouvir instruções.</span>
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-2">
          {/* Senior Mode Toggle Button */}
          <button
            onClick={() => {
              setIsSeniorMode(!isSeniorMode);
              setSeniorStep(1);
              if (isSpeaking) window.speechSynthesis.cancel();
            }}
            className={`px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center gap-1.5 ${
              isSeniorMode 
                ? 'bg-indigo-600/90 text-white shadow-xs' 
                : 'bg-white text-indigo-700 border border-indigo-200'
            }`}
            id="toggle-senior-mode"
          >
            <Accessibility className="w-4 h-4" />
            {isSeniorMode ? '✓ MODO IDOSO ATIVADO' : 'ATIVAR MODO IDOSO (FONTES GRANDES)'}
          </button>

          {/* High Contrast Toggle (only available if senior mode or requested) */}
          {isSeniorMode && (
            <button
              onClick={() => setIsHighContrast(!isHighContrast)}
              className={`px-4 py-2 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                isHighContrast 
                  ? 'bg-yellow-400 text-black border-2 border-slate-900' 
                  : 'bg-white text-slate-700 border border-slate-300'
              }`}
              id="toggle-high-contrast"
            >
              ☀ {isHighContrast ? 'ALTO CONTRASTE ATIVO' : 'ALTO CONTRASTE (PCD)'}
            </button>
          )}
        </div>
      </div>

      {!isAuthenticated ? (
        /* Form Login Block */
        <div className="max-w-md mx-auto bg-white border border-slate-200 p-6 rounded-2xl shadow-sm" id="guest-form-login">
          <div className="text-center space-y-2 mb-6">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-base">Portal de Registro de Hóspedes</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Para preservar seus dados em conformidade com a LGPD, o acesso à Rooming List requer o código confidencial do grupo e a senha fornecida pelo organizador.
            </p>
          </div>

          <form onSubmit={handleAuthenticate} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Selecione Seu Grupo de Viagem</label>
              <select
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 p-2.5 text-xs rounded-lg text-slate-800"
              >
                <option value="">Selecione o grupo...</option>
                {availableGroupAccessCodes.map(g => (
                  <option key={g.code} value={g.code}>{g.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Senha de Identificação do Grupo</label>
              <input
                type="password"
                placeholder="Ex e.g. canela2026"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 p-2 text-xs rounded-lg text-slate-800 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                A senha é criada pela agência para garantir que nenhum robô ou terceiro leia ou altere as informações dos quartos.
              </span>
            </div>

            {formError && (
              <div className="bg-red-50 text-red-700 text-xs p-3 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold p-2 text-xs rounded-lg cursor-pointer transition-colors"
            >
              Confirmar Link e Autenticar
            </button>
          </form>
        </div>
      ) : formSuccess ? (
        /* Dynamic Success view showcasing audit and safety logs */
        <div className="bg-white border border-slate-100 p-6 rounded-2xl shadow-sm text-center space-y-6" id="form-success-receipt">
          <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          
          <div className="space-y-2">
            <h3 className="text-xl font-bold text-slate-800">Seus dados estão protegidos e o cadastro foi recebido!</h3>
            <p className="text-slate-500 text-sm max-w-lg mx-auto">
              Obrigado, <strong>{name}</strong>. Suas informações sensíveis de alimentação e acessibilidade foram transmitidas sob criptografia ao <strong>{activeGroupName}</strong> parceiro e tratadas sob consentimento explícito.
            </p>
          </div>

          {savedConsentLog && (
            <div className="bg-slate-50 rounded-xl p-5 border border-slate-100 max-w-md mx-auto text-left text-xs space-y-3" id="consent-receipt-card">
              <div className="border-b border-slate-200 pb-2 flex items-center justify-between">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[10px]">Recibo Auditável LGPD</span>
                <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">ATIVADO</span>
              </div>
              <div className="space-y-1 text-slate-600 text-[11px]">
                <p><strong>Identificador Consentimento:</strong> <span className="font-mono text-indigo-700">{savedConsentLog.hash}</span></p>
                <p><strong>Data & Hora de Aceite:</strong> {savedConsentLog.timestamp}</p>
                <p><strong>IP do Provedor de Internet:</strong> {savedConsentLog.ip}</p>
                <p><strong>Agência Corresponsável:</strong> {savedConsentLog.agencia}</p>
                <p><strong>Finalidade Registrada:</strong> Segurança Alimentar, Acessibilidade PNE & Emergências de Saúde Coletiva na viagem</p>
              </div>
              <div className="pt-2 border-t border-slate-200">
                <p className="text-[10px] text-slate-400 italic">
                  Você pode solicitar ao hotel a revogação ou exclusão permanente deste dado a qualquer momento, até 24 horas após o check-out do estabelecimento.
                </p>
              </div>
            </div>
          )}

          <div className="flex justify-center gap-3">
            <button
              onClick={() => {
                setFormSuccess(false);
                setName('');
                setDocument('');
                setContact('');
                setAge('');
                setNeedsSpecialRoom(false);
                setSpecialRoomDetails('');
                setNeedsCrib(false);
                setFoodRestrictions('Nenhuma');
                setFoodRestrictionsDetails('');
                setLanguageHelp('Nenhum');
                setNeedsElderlyTechSupport(false);
                setLgpdConsentGiven(false);
                setSeniorStep(1);
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-4 py-2 rounded-lg cursor-pointer transition-colors"
            >
              Cadastrar Outro Membro da Família
            </button>
            <button
              onClick={() => setIsAuthenticated(false)}
              className="border border-slate-250 text-slate-700 hover:bg-slate-50 font-bold text-xs px-4 py-2 rounded-lg cursor-pointer transition-colors"
            >
              Sair da Sessão Segura
            </button>
          </div>
        </div>
      ) : (
        /* Real Form View */
        <div className={currentThemeClasses()} id="active-form-sheet">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-slate-100 pb-4 mb-6">
            <div>
              <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider block">Grupo Vinculado</span>
              <h2 className="text-lg font-bold text-slate-800">{activeGroupName}</h2>
            </div>
            <div className="text-slate-400 text-xs flex items-center gap-1">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
              Sessão Criptografada e Segura
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* -------------------- STANDARD FLOW -------------------- */}
            {!isSeniorMode ? (
              <div className="space-y-5" id="standard-mode-fields">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className={labelClasses()}>Nome Completo *</label>
                    <input
                      type="text"
                      placeholder="Nome completo do hóspede"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className={inputClasses()}
                      required
                    />
                  </div>
                  <div>
                    <label className={labelClasses()}>Documento (RG, CPF ou Passaporte) *</label>
                    <input
                      type="text"
                      placeholder="Inserir número oficial"
                      value={document}
                      onChange={(e) => setDocument(e.target.value)}
                      className={inputClasses()}
                      required
                    />
                  </div>
                  <div>
                    <label className={labelClasses()}>Idade *</label>
                    <input
                      type="number"
                      placeholder="Idade do hóspede"
                      value={age}
                      onChange={(e) => setAge(e.target.value === '' ? '' : Number(e.target.value))}
                      className={inputClasses()}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelClasses()}>Celular / Telefone de Contato *</label>
                    <input
                      type="tel"
                      placeholder="Ex: (51) 98888-7777"
                      value={contact}
                      onChange={(e) => setContact(e.target.value)}
                      className={inputClasses()}
                      required
                    />
                  </div>
                  <div>
                    <label className={labelClasses()}>País de Origem</label>
                    <input
                      type="text"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className={inputClasses()}
                    />
                  </div>
                </div>

                <div>
                  <label className={labelClasses()}>Endereço Completo</label>
                  <input
                    type="text"
                    placeholder="Rua, número, cidade e estado"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className={inputClasses()}
                  />
                </div>

                {/* Coringas: Acessilidade, Berço e Restrição Alimentar */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50 p-4 rounded-xl border border-slate-100" id="standard-coringa-grid">
                  
                  {/* Accessibility options */}
                  <div className="space-y-2">
                    <label className="text-xs font-extrabold text-slate-700 block flex items-center gap-1.5 uppercase">
                      <Accessibility className="w-4 h-4 text-indigo-500" />
                      1. Acessibilidade
                    </label>
                    <p className="text-[10px] text-slate-400">Requer quarto especial adaptado para cadeirantes ou idosos com barras de apoio no banheiro?</p>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
                        <input
                          type="radio"
                          name="needsSpecialRoom"
                          checked={needsSpecialRoom}
                          onChange={() => setNeedsSpecialRoom(true)}
                        />
                        Sim
                      </label>
                      <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
                        <input
                          type="radio"
                          name="needsSpecialRoom"
                          checked={!needsSpecialRoom}
                          onChange={() => {
                            setNeedsSpecialRoom(false);
                            setSpecialRoomDetails('');
                          }}
                        />
                        Não
                      </label>
                    </div>
                    {needsSpecialRoom && (
                      <textarea
                        placeholder="Ex: Dificuldade de subir escada, necessita de barras de segurança"
                        value={specialRoomDetails}
                        onChange={(e) => setSpecialRoomDetails(e.target.value)}
                        className="w-full bg-white border border-slate-200 p-2 text-xs rounded-lg mt-1"
                        rows={2}
                      />
                    )}
                  </div>

                  {/* Cradle Options */}
                  <div className="space-y-2">
                    <label className="text-xs font-extrabold text-slate-700 block flex items-center gap-1.5 uppercase">
                      <Baby className="w-4 h-4 text-indigo-500" />
                      2. Berço Móvel
                    </label>
                    <p className="text-[10px] text-slate-400">Viajando com bebês? Requer berço adicional posicionado próximo ao leito do quarto?</p>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
                        <input
                          type="radio"
                          name="needsCrib"
                          checked={needsCrib}
                          onChange={() => setNeedsCrib(true)}
                        />
                        Sim
                      </label>
                      <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
                        <input
                          type="radio"
                          name="needsCrib"
                          checked={!needsCrib}
                          onChange={() => setNeedsCrib(false)}
                        />
                        Não
                      </label>
                    </div>
                  </div>

                  {/* Food Restriction */}
                  <div className="space-y-2">
                    <label className="text-xs font-extrabold text-slate-700 block flex items-center gap-1.5 uppercase">
                      <Utensils className="w-4 h-4 text-indigo-500" />
                      3. Alimentar
                    </label>
                    <p className="text-[10px] text-slate-400">Indicar qualquer restrição ou alergia para darmos andamento à cozinha dietética antes do check-in.</p>
                    <select
                      value={foodRestrictions}
                      onChange={(e) => setFoodRestrictions(e.target.value)}
                      className="w-full bg-white border border-slate-200 p-1.5 text-xs rounded-lg"
                    >
                      <option value="Nenhuma">Nenhuma Restrição</option>
                      <option value="Vegetariano">Vegetariano</option>
                      <option value="Vegano">Vegano</option>
                      <option value="Sem Glúten">Sem Glúten (Celíaco)</option>
                      <option value="Sem Lactose">Sem Lactose</option>
                      <option value="Outra">Outra Alergia/Restrição</option>
                    </select>

                    {foodRestrictions !== 'Nenhuma' && (
                      <input
                        type="text"
                        placeholder="Detalhes (Ex: Alergia grave a amendoim)"
                        value={foodRestrictionsDetails}
                        onChange={(e) => setFoodRestrictionsDetails(e.target.value)}
                        className="w-full bg-white border border-slate-200 p-2 text-xs rounded-lg mt-1"
                      />
                    )}
                  </div>
                </div>

                {/* Additional Helpers */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className={labelClasses()}>Ajuda com Idiomas (Conversação no Check-in)</label>
                    <select
                      value={languageHelp}
                      onChange={(e) => setLanguageHelp(e.target.value)}
                      className={inputClasses()}
                    >
                      <option value="Nenhum">Falo e compreendo português nativo</option>
                      <option value="Inglês">Preciso de tradutor ou ajuda em Inglês</option>
                      <option value="Espanhol">Preciso de ajuda em Espanhol</option>
                      <option value="Libras">Comunicação fluente em LIBRAS</option>
                      <option value="Outro">Outro idioma</option>
                    </select>
                  </div>
                  <div className="flex items-center gap-2 pt-6">
                    <input
                      type="checkbox"
                      id="tech-support-checkbox"
                      checked={needsElderlyTechSupport}
                      onChange={(e) => setNeedsElderlyTechSupport(e.target.checked)}
                      className="w-4 h-4 text-indigo-600 border-slate-200 text-xs"
                    />
                    <label htmlFor="tech-support-checkbox" className="text-xs font-semibold text-slate-600 cursor-pointer">
                      Preciso de suporte com tecnologia no hotel (Instruções físicas, chaves comuns, etc.)
                    </label>
                  </div>
                </div>
              </div>
            ) : (
              /* -------------------- SENIOR ACCESSIBLE FLOW (WIZARD) -------------------- */
              <div className={`${isHighContrast ? 'border-4 border-black text-black' : 'bg-amber-50/40 border border-amber-100 p-6 rounded-2xl'} space-y-6`} id="senior-mode-fields">
                
                {/* Voice Guidance Active Indicator */}
                <div className="flex items-center justify-between bg-amber-500 text-slate-950 p-4 rounded-xl border border-amber-600/20" id="senior-voice-control-pnl">
                  <div className="flex items-center gap-3">
                    <Volume2 className="w-7 h-7 text-slate-950 animate-bounce shrink-0" />
                    <div>
                      <span className="font-extrabold text-sm block">Guia de Leitura por Voz para Idoso</span>
                      <span className="text-[11px] font-semibold opacity-90 block">Utilize o botão de ouvir para escutar as instruções de forma calma e pausada!</span>
                    </div>
                  </div>
                  {speechSupported ? (
                    <button
                      type="button"
                      onClick={() => {
                        let text = "";
                        if (seniorStep === 1) text = audioPrompts.step1;
                        else if (seniorStep === 2) text = audioPrompts.step2;
                        else if (seniorStep === 3) text = audioPrompts.step3;
                        else text = audioPrompts.step4;
                        handleSpeakText(text);
                      }}
                      className="bg-slate-950 hover:bg-slate-900 text-white font-extrabold px-4 py-2.5 rounded-lg text-xs cursor-pointer transition-colors shrink-0 flex items-center gap-1.5"
                    >
                      {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      {isSpeaking ? 'PARAR DE OUVIR' : 'OUVIR INSTRUÇÕES'}
                    </button>
                  ) : (
                    <span className="text-xs font-bold text-amber-950">Voz Indisponível no Navegador</span>
                  )}
                </div>

                {/* Pulse Visualizer when speaking */}
                {isSpeaking && (
                  <div className="flex justify-center items-center gap-1 py-1" id="voice-waves">
                    <span className="w-1 h-6 bg-amber-950 animate-pulse rounded-full" />
                    <span className="w-1 h-3 bg-amber-950 animate-pulse rounded-full" style={{ animationDelay: '0.1s' }} />
                    <span className="w-1 h-5 bg-amber-950 animate-pulse rounded-full" style={{ animationDelay: '0.2s' }} />
                    <span className="w-1 h-2 bg-amber-950 animate-pulse rounded-full" style={{ animationDelay: '0.3s' }} />
                    <span className="w-1 h-8 bg-amber-950 animate-pulse rounded-full" style={{ animationDelay: '0.4s' }} />
                    <span className="w-1 h-4 bg-amber-950 animate-pulse rounded-full" style={{ animationDelay: '0.5s' }} />
                  </div>
                )}

                {/* Steps Visual Navigator */}
                <div className="flex justify-between items-center bg-white p-3 rounded-xl border border-amber-200" id="senior-wizard-bullets">
                  {['1. Identidade', '2. Contato', '3. Saúde/Leito', '4. Apoio & LGPD'].map((lbl, idx) => {
                    const stepNum = idx + 1;
                    const isActive = seniorStep === stepNum;
                    const isPassed = seniorStep > stepNum;
                    return (
                      <div key={idx} className="flex items-center gap-1.5">
                        <span className={`w-6 h-6 flex items-center justify-center rounded-full text-xs font-bold ${
                          isActive 
                            ? 'bg-slate-950 text-white ring-4 ring-amber-300' 
                            : isPassed 
                            ? 'bg-emerald-600 text-white' 
                            : 'bg-slate-200 text-slate-500'
                        }`}>
                          {stepNum}
                        </span>
                        <span className={`hidden md:inline font-bold text-xs ${isActive ? 'text-slate-900 border-b-2 border-amber-400' : 'text-slate-500'}`}>
                          {lbl}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* STEP 1 */}
                {seniorStep === 1 && (
                  <div className="space-y-4" id="step-1-inputs">
                    <div>
                      <label className={labelClasses()}>Escreva seu Nome Completo abaixo *</label>
                      <input
                        type="text"
                        placeholder="Ex: João da Silva Santos"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className={inputClasses()}
                        required
                      />
                      <span className="text-slate-500 text-xs mt-1 block">Atenção: escreva o nome como consta no RG para garantir segurança no check-in do hotel.</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className={labelClasses()}>Qual o número do seu Documento? *</label>
                        <input
                          type="text"
                          placeholder="Digite seu RG ou CPF"
                          value={document}
                          onChange={(e) => setDocument(e.target.value)}
                          className={inputClasses()}
                          required
                        />
                      </div>
                      <div>
                        <label className={labelClasses()}>Qual a sua Idade? *</label>
                        <input
                          type="number"
                          placeholder="Ex: 75"
                          value={age}
                          onChange={(e) => setAge(e.target.value === '' ? '' : Number(e.target.value))}
                          className={inputClasses()}
                          required
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 2 */}
                {seniorStep === 2 && (
                  <div className="space-y-4" id="step-2-inputs">
                    <div>
                      <label className={labelClasses()}>Qual o seu Telefone ou WhatsApp de contato? *</label>
                      <input
                        type="tel"
                        placeholder="Ex: (51) 98888-8888"
                        value={contact}
                        onChange={(e) => setContact(e.target.value)}
                        className={inputClasses()}
                        required
                      />
                      <span className="text-slate-500 text-xs mt-1 block">Crucial para o hotel e agremiação entrarem em contato rápido em casos de emergência.</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className={labelClasses()}>País Onde Você Vive</label>
                        <input
                          type="text"
                          value={country}
                          onChange={(e) => setCountry(e.target.value)}
                          className={inputClasses()}
                        />
                      </div>
                      <div>
                        <label className={labelClasses()}>Qual o seu Endereço Residencial?</label>
                        <input
                          type="text"
                          placeholder="Rua, Número, Cidade e Estado"
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          className={inputClasses()}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 3 */}
                {seniorStep === 3 && (
                  <div className="space-y-6" id="step-3-inputs">
                    
                    {/* Accessibility Needs */}
                    <div className="bg-white p-4 rounded-xl border border-amber-200">
                      <label className={labelClasses()}>Você necessita de quarto com barras de apoio ou adaptado para cadeirantes/idosos?</label>
                      <div className="flex gap-6 mt-2">
                        <label className="flex items-center gap-2 text-base font-extrabold text-slate-800 cursor-pointer">
                          <input
                            type="radio"
                            name="needsSpecialRoom"
                            checked={needsSpecialRoom}
                            onChange={() => setNeedsSpecialRoom(true)}
                            className="w-5 h-5 text-indigo-600"
                          />
                          SIM, preciso de quarto adaptado
                        </label>
                        <label className="flex items-center gap-2 text-base font-extrabold text-slate-800 cursor-pointer">
                          <input
                            type="radio"
                            name="needsSpecialRoom"
                            checked={!needsSpecialRoom}
                            onChange={() => {
                              setNeedsSpecialRoom(false);
                              setSpecialRoomDetails('');
                            }}
                            className="w-5 h-5 text-indigo-600"
                          />
                          NÃO preciso
                        </label>
                      </div>
                      {needsSpecialRoom && (
                        <textarea
                          placeholder="Descreva aqui sua necessidade física (Ex: Não posso subir escadas, preciso de andar baixo)"
                          value={specialRoomDetails}
                          onChange={(e) => setSpecialRoomDetails(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-300 p-2 text-base rounded-lg mt-3 text-slate-900"
                          rows={2}
                        />
                      )}
                    </div>

                    {/* Food restrictions */}
                    <div className="bg-white p-4 rounded-xl border border-amber-200">
                      <label className={labelClasses()}>Você possui restrição alimentar ou alergia séria?</label>
                      <p className="text-slate-500 text-xs mb-2">Isso ajuda o cozinheiro do hotel a separar panelas sem glúten ou alergênicos para sua total segurança física!</p>
                      <select
                        value={foodRestrictions}
                        onChange={(e) => setFoodRestrictions(e.target.value)}
                        className="w-full bg-white border border-slate-300 p-2.5 text-base rounded-xl text-slate-900 font-bold"
                      >
                        <option value="Nenhuma">Não possuo, como de tudo</option>
                        <option value="Vegetariano">Sou Vegetariano</option>
                        <option value="Vegano">Sou Vegano</option>
                        <option value="Sem Glúten">Não posso Glúten (Doença Celíaca)</option>
                        <option value="Sem Lactose">Sem Lactose (Derivados do leite)</option>
                        <option value="Outra">Outra Alergia (Amendoim, etc.)</option>
                      </select>

                      {foodRestrictions !== 'Nenhuma' && (
                        <input
                          type="text"
                          placeholder="Especifique o alimento. Ex: Alergia grave a amendoim e castanhas"
                          value={foodRestrictionsDetails}
                          onChange={(e) => setFoodRestrictionsDetails(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-300 p-2 text-xs rounded-lg mt-3"
                        />
                      )}
                    </div>

                    {/* Crib needs */}
                    <div className="bg-white p-4 rounded-xl border border-amber-200">
                      <label className={labelClasses()}>Precisa de berço no quarto?</label>
                      <div className="flex gap-6 mt-2">
                        <label className="flex items-center gap-2 text-base font-extrabold text-slate-800 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={needsCrib}
                            onChange={(e) => setNeedsCrib(e.target.checked)}
                            className="w-5 h-5 text-indigo-600 rounded"
                          />
                          SIM, preciso de berço
                        </label>
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 4 */}
                {seniorStep === 4 && (
                  <div className="space-y-5" id="step-4-inputs">
                    <div className="bg-white p-4 rounded-xl border border-amber-200 space-y-3">
                      <label className={labelClasses()}>Ajuda Adicional para Idosos & Inclusão</label>
                      
                      <div className="flex items-start gap-3 p-2 bg-rose-50/50 rounded-lg">
                        <input
                          type="checkbox"
                          id="needs-tech-support-senior"
                          checked={needsElderlyTechSupport}
                          onChange={(e) => setNeedsElderlyTechSupport(e.target.checked)}
                          className="w-5 h-5 text-indigo-600 rounded mt-0.5"
                        />
                        <label htmlFor="needs-tech-support-senior" className="text-xs font-bold text-slate-700 cursor-pointer">
                          Desejo receber chave física comum (chaveiro) do quarto em vez de aplicativo no celular e apoio presencial no check-in.
                        </label>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-600 mb-1">Idioma preferencial para contato ou recepção</label>
                        <select
                          value={languageHelp}
                          onChange={(e) => setLanguageHelp(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-300 p-2 text-sm rounded-lg"
                        >
                          <option value="Nenhum">Falo Português</option>
                          <option value="Inglês">Falo Inglês</option>
                          <option value="Espanhol">Falo Espanhol</option>
                          <option value="Libras">Comunicação em LIBRAS</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Senior Wizard Navigation actions */}
                <div className="flex justify-between gap-4 pt-4 border-t border-amber-200">
                  <button
                    type="button"
                    onClick={prevSeniorStep}
                    disabled={seniorStep === 1}
                    className={`px-4 py-3 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all ${
                      seniorStep === 1 
                        ? 'opacity-30 cursor-not-allowed bg-slate-200 text-slate-400' 
                        : 'bg-white text-slate-800 border border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <ArrowLeft className="w-4 h-4" />
                    PASSO ANTERIOR
                  </button>

                  {seniorStep < 4 ? (
                    <button
                      type="button"
                      onClick={nextSeniorStep}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-3 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      PASSO SEGUINTE
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : null}
                </div>
              </div>
            )}

            {/* -------------------- LGPD CONSENT ZONE (SHARED BY BOTH FLOWS) -------------------- */}
            <div className="bg-indigo-950 text-slate-100 p-5 rounded-2xl space-y-4" id="lgpd-consent-card">
              <div className="flex items-center justify-between border-b border-indigo-900 pb-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  <h3 className="text-xs font-bold uppercase tracking-wider">Declaração Legítima de Consentimento LGPD</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setShowLGPDDetailPanel(!showLGPDDetailPanel)}
                  className="text-[10px] text-indigo-300 font-medium hover:underline flex items-center gap-0.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  {showLGPDDetailPanel ? 'Ocultar Detalhes' : 'Por que pedimos isso?'}
                </button>
              </div>

              {showLGPDDetailPanel && (
                <div className="bg-indigo-900/55 text-[11px] leading-relaxed p-4 rounded-xl border border-indigo-805 space-y-1.5 text-slate-200">
                  <p>
                    <strong>Por que coletamos dados coringa de alimentação e acessibilidade?</strong>
                    <br />
                    Esses dados são classificados como <strong>dados pessoais sensíveis de saúde</strong> pela LGPD. Nós exigimos seu consentimento justificado pelas seguintes prerrogativas:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-slate-300">
                    <li><strong>Alimentação:</strong> Previne paradas cardiorrespiratórias e choque anafilático no restaurante do hotel.</li>
                    <li><strong>Acessibilidade:</strong> Em casos de incidentes ou planos de emergência contra incêndios, as equipes médicas e brigadistas localizam PCDs e idosos de mobilidade restrita com prioridade total.</li>
                  </ul>
                  <p className="text-[10px] text-slate-400">
                    Sua assinatura digital gerará um recibo com código de integridade que impede a transferência destes dados para terceiros ou uso em marketing.
                  </p>
                </div>
              )}

              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  id="lgpd-opt-in"
                  checked={lgpdConsentGiven}
                  onChange={(e) => setLgpdConsentGiven(e.target.checked)}
                  className="w-5 h-5 text-indigo-600 border-indigo-800 rounded focus:ring-indigo-500 mt-0.5"
                  required
                />
                <label htmlFor="lgpd-opt-in" className="text-xs leading-relaxed text-slate-200 cursor-pointer font-medium">
                  <strong>Eu autorizo formalmente</strong> o compartilhamento confidencial das minhas restrições alimentares e de mobilidade de saúde ao hotel parceiro e agência, para fins exclusivos de personalização da minha segurança, integridade física e conforto durante o período de hospedagem deste grupo. *
                </label>
              </div>
            </div>

            {formError && (
              <div className="bg-red-50 text-red-800 text-xs p-3 rounded-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Standard flow finalize or senior flow finalize */}
            {(!isSeniorMode || seniorStep === 4) && (
              <button
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold p-3 text-sm rounded-lg cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                id="btn-submit-guest"
              >
                <ShieldCheck className="w-5 h-5" />
                FINALIZAR E ENVIAR CADASTRO SEGURO LGPD
              </button>
            )}
          </form>
        </div>
      )}
    </div>
  );
}
