import React, { useState } from 'react';
import { Group, Guest, Room } from '../types';
import { 
  Home, 
  UserPlus, 
  UserCheck, 
  Trash2, 
  AlertCircle, 
  Plus, 
  Baby, 
  ShieldAlert, 
  CheckCircle,
  HelpCircle,
  HeartHandshake,
  HeartCrack,
  Flame,
  ArrowRight
} from 'lucide-react';

interface RoomingMindMapProps {
  group: Group;
  onUpdateGroup: (updatedGroup: Group) => void;
}

export default function RoomingMindMap({ group, onUpdateGroup }: RoomingMindMapProps) {
  const [selectedGuestId, setSelectedGuestId] = useState<string | null>(null);
  const [newRoomNumber, setNewRoomNumber] = useState('');
  const [newRoomType, setNewRoomType] = useState<'Duplo' | 'Triplo' | 'Casal' | 'Individual'>('Duplo');
  const [newRoomAccessibility, setNewRoomAccessibility] = useState(false);
  const [newRoomHasCrib, setNewRoomHasCrib] = useState(false);
  const [showAddRoomForm, setShowAddRoomForm] = useState(false);

  // Unassigned guests
  const unassignedGuests = group.guests.filter(g => !g.roomId);

  // Assign a guest to a room
  const handleAssignGuest = (guestId: string, roomId: string) => {
    const room = group.rooms.find(r => r.id === roomId);
    if (!room) return;

    if (room.guestIds.length >= room.capacity) {
      alert(`O Quarto ${room.number} já atingiu a capacidade máxima de ${room.capacity} pessoas!`);
      return;
    }

    const updatedGuests = group.guests.map(g => {
      if (g.id === guestId) {
        return { 
          ...g, 
          roomId,
          errors: g.errors.filter(e => e !== 'Não associado a nenhum quarto')
        };
      }
      return g;
    });

    const updatedRooms = group.rooms.map(r => {
      if (r.id === roomId) {
        return { ...r, guestIds: [...r.guestIds, guestId] };
      }
      return r;
    });

    onUpdateGroup({
      ...group,
      guests: updatedGuests,
      rooms: updatedRooms
    });
    setSelectedGuestId(null);
  };

  // Remove guest from custody
  const handleRemoveGuestFromRoom = (guestId: string, roomId: string) => {
    const updatedGuests = group.guests.map(g => {
      if (g.id === guestId) {
        // Add unassigned error if appropriate
        const errors = [...g.errors];
        if (!errors.includes('Não associado a nenhum quarto')) {
          errors.push('Não associado a nenhum quarto');
        }
        return { ...g, roomId: undefined, errors };
      }
      return g;
    });

    const updatedRooms = group.rooms.map(r => {
      if (r.id === roomId) {
        return { ...r, guestIds: r.guestIds.filter(id => id !== guestId) };
      }
      return r;
    });

    onUpdateGroup({
      ...group,
      guests: updatedGuests,
      rooms: updatedRooms
    });
  };

  // Add a new custom room
  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomNumber.trim()) return;

    // Check pre-existence
    if (group.rooms.some(r => r.number === newRoomNumber)) {
      alert(`Quarto ${newRoomNumber} já existe!`);
      return;
    }

    let capacity = 2;
    if (newRoomType === 'Triplo') capacity = 3;
    if (newRoomType === 'Individual') capacity = 1;

    const newRoom: Room = {
      id: `room_${Date.now()}`,
      number: newRoomNumber,
      type: newRoomType,
      capacity,
      accessibilityFriendly: newRoomAccessibility,
      hasCrib: newRoomHasCrib,
      guestIds: []
    };

    onUpdateGroup({
      ...group,
      rooms: [...group.rooms, newRoom]
    });

    setNewRoomNumber('');
    setNewRoomAccessibility(false);
    setNewRoomHasCrib(false);
    setShowAddRoomForm(false);
  };

  // Automated checks & Mind Map intelligence
  const generateCompatibilityWarnings = () => {
    const warnings: { title: string; message: string; severity: 'high' | 'medium' | 'low'; type: string; roomId?: string }[] = [];

    group.rooms.forEach(room => {
      const roomGuests = group.guests.filter(g => room.guestIds.includes(g.id));
      if (roomGuests.length === 0) return;

      // 1. Accessibility mismatch
      const needsSpecial = roomGuests.find(g => g.needsSpecialRoom);
      if (needsSpecial && !room.accessibilityFriendly) {
        warnings.push({
          title: `Incompatibilidade de Acessibilidade (Quarto ${room.number})`,
          message: `${needsSpecial.name} necessita de quarto especial adaptado, mas o Quarto ${room.number} não possui adaptações para PNE/Acessabilidade.`,
          severity: 'high',
          type: 'accessibility',
          roomId: room.id
        });
      }

      // 2. Crib mismatch
      const needsCrib = roomGuests.find(g => g.needsCrib);
      if (needsCrib && !room.hasCrib) {
        warnings.push({
          title: `Berço indisponível (Quarto ${room.number})`,
          message: `${needsCrib.name} solicitou um berço infantil, porém o Quarto ${room.number} não foi configurado para suportar berço na rooming list.`,
          severity: 'medium',
          type: 'crib',
          roomId: room.id
        });
      }

      // 3. Isolated senior assistance
      const elder = roomGuests.find(g => g.age >= 75);
      if (elder && roomGuests.length === 1 && elder.needsElderlyTechSupport) {
        warnings.push({
          title: `Sênior Alocado Sozinho (Quarto ${room.number})`,
          message: `${elder.name} (${elder.age} anos) solicitou apoio presencial de tecnologia e está sozinho no Quarto ${room.number}. A recepção precisa agendar visita diária.`,
          severity: 'medium',
          type: 'elderly-alone',
          roomId: room.id
        });
      }

      // 4. Group allergen check (Gluten Celiac or lactose severities)
      const celiac = roomGuests.find(g => g.foodRestrictions === 'Sem Glúten' && g.foodRestrictionsDetails?.toLowerCase().includes('celíac'));
      if (celiac) {
        warnings.push({
          title: `Hóspede Celíaco no Quarto ${room.number}`,
          message: `Segurança Alimentar: ${celiac.name} possui Doença Celíaca Severa. O frigobar do Quarto ${room.number} deve ser minuciosamente limpo e isento de produtos com glúten antes do check-in.`,
          severity: 'high',
          type: 'celiac-safety',
          roomId: room.id
        });
      }

      // 5. Gender check optional warning for mixed roommates if different ages/families
      if (roomGuests.length > 1) {
        const elderlyTechCheck = roomGuests.filter(g => g.needsElderlyTechSupport);
        if (elderlyTechCheck.length > 0 && elderlyTechCheck.length !== roomGuests.length) {
          // Mixed young and elderly roommate mapping
          warnings.push({
            title: `Quarto de Geração Mista (Quarto ${room.number})`,
            message: `Compartilhamento de quarto entre sênior necessitado de apoio (${elderlyTechCheck.map(e => e.name).join(', ')}) e hóspedes mais jovens. Confirmar vínculo familiar para evitar constrangimento.`,
            severity: 'low',
            type: 'generation-mix',
            roomId: room.id
          });
        }
      }
    });

    // Unassigned list alert
    if (unassignedGuests.length > 0) {
      warnings.push({
        title: 'Hóspedes pendentes de quarto',
        message: `Existem ${unassignedGuests.length} hóspedes na rodada atual que ainda não possuem um quarto correspondente no mapa mental.`,
        severity: 'medium',
        type: 'unassigned'
      });
    }

    return warnings;
  };

  const currentWarnings = generateCompatibilityWarnings();

  return (
    <div className="space-y-6" id="rooming-mindmap-root">
      {/* Action Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-900 text-white p-5 rounded-2xl shadow-sm" id="map-header">
        <div>
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Home className="w-5 h-5 text-indigo-400" />
            Mapa Mental de Ocupação de Apartamentos & Quartos
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Associe os hóspedes cadastrados com os quartos disponíveis. O sistema valida dados de saúde e preferências em tempo real.
          </p>
        </div>
        <button
          onClick={() => setShowAddRoomForm(!showAddRoomForm)}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          id="btn-toggle-add-room"
        >
          <Plus className="w-4 h-4" />
          {showAddRoomForm ? 'Fechar Cadastro' : 'Cadastrar Quarto'}
        </button>
      </div>

      {/* Add Room Modal/Form */}
      {showAddRoomForm && (
        <form onSubmit={handleAddRoom} className="bg-slate-50 border border-slate-200 p-5 rounded-xl space-y-4 shadow-inner" id="add-room-form">
          <h3 className="font-bold text-xs text-slate-700 uppercase tracking-wider">Novo Apartamento Comercial</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Número do Quarto</label>
              <input
                type="text"
                placeholder="Ex: 105"
                value={newRoomNumber}
                onChange={(e) => setNewRoomNumber(e.target.value)}
                className="w-full bg-white border border-slate-300 p-2 text-xs rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Tipo de Leito</label>
              <select
                value={newRoomType}
                onChange={(e) => setNewRoomType(e.target.value as any)}
                className="w-full bg-white border border-slate-300 p-2 text-xs rounded-lg text-slate-800"
              >
                <option value="Individual">Individual (1 pessoa)</option>
                <option value="Duplo">Duplo Solteiro (2 pessoas)</option>
                <option value="Casal">Casal (2 pessoas)</option>
                <option value="Triplo">Triplo (3 pessoas)</option>
              </select>
            </div>
            <div className="flex items-center gap-2 pt-6">
              <input
                type="checkbox"
                id="acc-friendly"
                checked={newRoomAccessibility}
                onChange={(e) => setNewRoomAccessibility(e.target.checked)}
                className="w-4 h-4 text-indigo-600 border-slate-300 rounded-sm focus:ring-indigo-500"
              />
              <label htmlFor="acc-friendly" className="text-xs text-slate-600 cursor-pointer">
                Acessível (PNE / Idoso)
              </label>
            </div>
            <div className="flex items-center gap-2 pt-6">
              <input
                type="checkbox"
                id="with-crib"
                checked={newRoomHasCrib}
                onChange={(e) => setNewRoomHasCrib(e.target.checked)}
                className="w-4 h-4 text-indigo-600 border-slate-300 rounded-sm focus:ring-indigo-500"
              />
              <label htmlFor="with-crib" className="text-xs text-slate-600 cursor-pointer">
                Suporta Berço
              </label>
            </div>
          </div>
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs px-4 py-2 rounded-lg cursor-pointer transition-colors"
          >
            Adicionar ao Inventário
          </button>
        </form>
      )}

      {/* Main Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="mindmap-workspace">
        {/* Left Side: Unassigned Guest Cards */}
        <div className="lg:col-span-4 bg-white border border-slate-200 p-4 rounded-xl flex flex-col h-[550px]" id="unassigned-guests-panel">
          <div className="mb-3 border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-700 text-sm flex items-center justify-between">
              <span>Hóspedes por Alocar ({unassignedGuests.length})</span>
              {selectedGuestId && (
                <button 
                  onClick={() => setSelectedGuestId(null)}
                  className="text-[10px] text-indigo-600 font-medium hover:underline cursor-pointer"
                >
                  Cancelar seleção
                </button>
              )}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Clique em um hóspede e depois em "Alocar" no quarto desejado.
            </p>
          </div>

          <div className="space-y-3 overflow-y-auto flex-1 pr-1" id="unassigned-cards-container">
            {unassignedGuests.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center p-6 text-slate-400 gap-2">
                <CheckCircle className="w-8 h-8 text-emerald-500" />
                <span className="text-xs font-semibold text-slate-600">Tudo pronto!</span>
                <span className="text-[10px] text-slate-400 leading-relaxed">Todos os hóspedes já estão nos seus quartos ou não há ninguém cadastrado.</span>
              </div>
            ) : (
              unassignedGuests.map(guest => {
                const isSelected = selectedGuestId === guest.id;
                return (
                  <div
                    key={guest.id}
                    onClick={() => setSelectedGuestId(guest.id)}
                    className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      isSelected 
                        ? 'bg-indigo-50/55 border-indigo-600 shadow-sm' 
                        : 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                    }`}
                    id={`unassigned-guest-${guest.id}`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-bold text-slate-800 text-xs">{guest.name}</h4>
                        <div className="flex flex-wrap gap-1 mt-1">
                          <span className="bg-slate-200 text-slate-700 text-[9px] px-1.5 py-0.5 rounded-full font-medium">
                            {guest.age} anos
                          </span>
                          {guest.needsSpecialRoom && (
                            <span className="bg-amber-100 text-amber-800 text-[9px] px-1.5 py-0.5 rounded-full font-bold">
                              Especial PNE
                            </span>
                          )}
                          {guest.needsCrib && (
                            <span className="bg-sky-100 text-sky-800 text-[9px] px-1.5 py-0.5 rounded-full font-bold inline-flex items-center gap-0.5">
                              <Baby className="w-2 h-2" /> Berço
                            </span>
                          )}
                          {guest.foodRestrictions !== 'Nenhuma' && (
                            <span className="bg-violet-100 text-violet-800 text-[9px] px-1.5 py-0.5 rounded-full font-medium">
                              Restrição: {guest.foodRestrictions}
                            </span>
                          )}
                          {guest.needsElderlyTechSupport && (
                            <span className="bg-rose-100 text-rose-800 text-[9px] px-1.5 py-0.5 rounded-full font-medium">
                              Apoio Sênior
                            </span>
                          )}
                        </div>
                      </div>
                      <div className={`p-1 rounded-full ${isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
                        <UserPlus className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side: Rooms Interactive Map Grid */}
        <div className="lg:col-span-8 space-y-6" id="rooms-map-grid-panel">
          <div className="bg-white border border-slate-200 p-4 rounded-xl flex flex-col h-[550px]" id="rooms-map-scroll">
            <h3 className="font-bold text-slate-700 text-sm mb-2">Mapa de Leitos do Hotel</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 overflow-y-auto pr-1 py-1" id="rooms-grid">
              {group.rooms.map(room => {
                const occupants = group.guests.filter(g => room.guestIds.includes(g.id));
                const isFull = occupants.length >= room.capacity;

                return (
                  <div 
                    key={room.id}
                    className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 flex flex-col justify-between hover:border-slate-300 hover:shadow-xs transition-all relative"
                    id={`room-card-${room.id}`}
                  >
                    {/* Room Metadata Indicators */}
                    <div className="flex items-start justify-between border-b border-slate-200/60 pb-2 mb-3">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-slate-900 text-sm">Apto {room.number}</span>
                          <span className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-sm font-medium">
                            {room.type}
                          </span>
                        </div>
                        <div className="flex gap-1.5 mt-1">
                          {room.accessibilityFriendly && (
                            <span className="text-[9px] text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded font-bold" title="Portas largas, barras de apoio, acessível">
                              Acessível/PNE
                            </span>
                          )}
                          {room.hasCrib && (
                            <span className="text-[9px] text-sky-700 bg-sky-100 px-1.5 py-0.2 rounded font-bold">
                              Estrutura p/ Berço
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[11px] font-bold text-slate-500">
                          {occupants.length} / {room.capacity} Ocupantes
                        </span>
                        <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden mt-1 ml-auto">
                          <div 
                            className={`h-full ${isFull ? 'bg-indigo-600' : 'bg-amber-400'}`} 
                            style={{ width: `${(occupants.length / room.capacity) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Room Slots Map */}
                    <div className="space-y-2 flex-grow min-h-[90px]" id={`room-slots-${room.id}`}>
                      {occupants.map(guest => (
                        <div 
                          key={guest.id} 
                          className="bg-white border border-slate-200 rounded-lg p-2 flex items-center justify-between text-xs"
                          id={`room-occupant-${guest.id}`}
                        >
                          <div className="flex items-center gap-1.5">
                            <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                            <div>
                              <span className="font-semibold text-slate-800 block text-[11px]">{guest.name}</span>
                              <span className="text-[9px] text-slate-500">
                                {guest.age} anos {guest.foodRestrictions !== 'Nenhuma' ? `• Restriction: ${guest.foodRestrictions}` : ''}
                              </span>
                            </div>
                          </div>
                          <button
                            onClick={() => handleRemoveGuestFromRoom(guest.id, room.id)}
                            className="p-1 text-slate-400 hover:text-rose-500 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Remover hóspede deste apartamento"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}

                      {/* Display Empty Slots */}
                      {Array.from({ length: Math.max(0, room.capacity - occupants.length) }).map((_, idx) => (
                        <div 
                          key={`empty-${idx}`} 
                          className="border border-dashed border-slate-300 rounded-lg p-3 flex items-center justify-between bg-white/40"
                        >
                          <span className="text-[10px] text-slate-400 font-medium">Espaço livre de leito</span>
                          {selectedGuestId ? (
                            <button
                              onClick={() => handleAssignGuest(selectedGuestId, room.id)}
                              className="text-[10px] bg-indigo-600 text-white font-medium px-2 py-0.5 rounded hover:bg-indigo-500 flex items-center gap-0.5 cursor-pointer transition-colors"
                            >
                              Alocar
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          ) : (
                            <span className="text-[9px] text-slate-300">Aguardando hóspede</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Connection MindMap Compatibility Diagnostics Panel */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs p-5" id="mindmap-diagnostics-bar">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-amber-500 animate-pulse" />
            Central de Diagnóstico & Validação Clínica / Conforto do Grupo
          </h3>
          <span className="text-[10px] bg-indigo-50 text-indigo-700 font-semibold px-2 py-0.5 rounded border border-indigo-100">
            {currentWarnings.length} ocorrências identificadas
          </span>
        </div>

        {currentWarnings.length === 0 ? (
          <div className="flex items-center gap-3 bg-emerald-50 border border-emerald-100 p-4 rounded-lg text-emerald-800 text-xs">
            <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold">Nenhuma incompatibilidade encontrada!</span> Todos os hóspedes estão organizados de maneira ideal que respeita limitações físicas, necessidades de berço para bebês, dietas restritivas cruciais e proteção social ativa.
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3" id="diagnostics-list">
            {currentWarnings.map((warning, i) => {
              const selectColor = () => {
                if (warning.severity === 'high') return 'bg-rose-50 border-rose-100 text-rose-800';
                if (warning.severity === 'medium') return 'bg-amber-50 border-amber-100 text-amber-800';
                return 'bg-blue-50 border-blue-100 text-blue-800';
              };

              const selectIcon = () => {
                if (warning.type === 'accessibility') return <HeartCrack className="w-5 h-5 text-rose-600 shrink-0" />;
                if (warning.type === 'celiac-safety') return <Flame className="w-5 h-5 text-rose-600 shrink-0" />;
                if (warning.type === 'elderly-alone') return <HeartHandshake className="w-5 h-5 text-amber-600 shrink-0" />;
                return <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />;
              };

              return (
                <div key={i} className={`p-3 rounded-lg border flex gap-2.5 text-xs ${selectColor()}`} id={`warning-card-${i}`}>
                  <div className="mt-0.5">{selectIcon()}</div>
                  <div className="space-y-0.5">
                    <h4 className="font-bold shrink-0">{warning.title}</h4>
                    <p className="opacity-90 leading-relaxed text-[11px]">{warning.message}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
