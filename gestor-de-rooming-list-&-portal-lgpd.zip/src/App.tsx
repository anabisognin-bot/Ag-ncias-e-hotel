import React, { useState } from 'react';
import { mockGroups, mockNotifications } from './data/mockData';
import { Group, Guest, SystemNotification } from './types';
import GroupDashboard from './components/GroupDashboard';
import RoomingMindMap from './components/RoomingMindMap';
import GuestForm from './components/GuestForm';
import UsageGuide from './components/UsageGuide';
import { 
  ShieldCheck, 
  Users, 
  Bell, 
  BookOpen, 
  UserPlus, 
  Home, 
  Lock, 
  HeartHandshake, 
  AlertCircle,
  HelpCircle,
  X
} from 'lucide-react';

export default function App() {
  const [groups, setGroups] = useState<Group[]>(mockGroups);
  const [selectedGroupId, setSelectedGroupId] = useState<string>('grp_001');
  const [notifications, setNotifications] = useState<SystemNotification[]>(mockNotifications);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'map' | 'register' | 'guide'>('dashboard');
  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState(false);

  const currentGroup = groups.find(g => g.id === selectedGroupId) || groups[0];

  // Handler to update the selected group properties (guests, rooms etc)
  const handleUpdateGroup = (updatedGroup: Group) => {
    const updatedGroups = groups.map(g => g.id === updatedGroup.id ? updatedGroup : g);
    setGroups(updatedGroups);

    // Dynamic warning adjustment: If the updated group has guests with missing info, adjust notifications
    const incompleteGuests = updatedGroup.guests.filter(g => g.errors.length > 0);
    
    if (incompleteGuests.length > 0) {
      const topIncomplete = incompleteGuests[0];
      // Check if notification already exists
      const exists = notifications.some(n => n.message.includes(topIncomplete.name));
      if (!exists) {
        const newNotif: SystemNotification = {
          id: `not_dy_${Date.now()}`,
          type: 'warning',
          title: `Omissão de dados: ${topIncomplete.name}`,
          message: `O hóspede cadastrado sob ID ${topIncomplete.id.substring(4, 8)} possui ${topIncomplete.errors.length} campos de saúde/acessibilidade pendentes.`,
          date: new Date().toISOString(),
          read: false
        };
        setNotifications(prev => [newNotif, ...prev]);
      }
    }
  };

  // Handler to append a newly registered guest from the client portal
  const handleGuestRegistered = (newGuest: Guest) => {
    // Check if the current selected group is the target
    // In actual production, it links via group access code but here we push to currently selected group
    const updatedGroup = {
      ...currentGroup,
      guests: [...currentGroup.guests, newGuest]
    };

    handleUpdateGroup(updatedGroup);

    // Fire alert about new registration
    const newNotif: SystemNotification = {
      id: `not_reg_${Date.now()}`,
      type: 'success',
      title: 'Novo Cadastro de Hospedagem Recebido',
      message: `${newGuest.name} preencheu a ficha e concordou com os termos da LGPD.`,
      date: new Date().toISOString(),
      read: false
    };

    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleDismissNotification = (notifId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notifId));
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadNotifCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans" id="app-root-container">
      
      {/* Dynamic Header Navbar Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40" id="main-app-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Logo Brand / Human naming constraints */}
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-indigo-600 text-white rounded-lg flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-5.5 h-5.5" />
            </div>
            <div>
              <span className="font-extrabold text-slate-950 text-sm tracking-tight block">Rooming Guard LGPD</span>
              <span className="text-[10px] text-slate-400 font-semibold block leading-none">Gestor de Quartos & Acessibilidade</span>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-bold" id="main-desktop-nav">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                activeTab === 'dashboard' 
                  ? 'bg-indigo-50 text-indigo-700' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Painel Geral
            </button>
            <button
              onClick={() => setActiveTab('map')}
              className={`px-3 py-2 rounded-lg cursor-pointer transition-colors flex items-center gap-1.5 ${
                activeTab === 'map' 
                  ? 'bg-indigo-50 text-indigo-700' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Home className="w-4 h-4" />
              Mapa de Quartos
            </button>
            <button
              onClick={() => setActiveTab('register')}
              className={`px-3 py-2 rounded-lg cursor-pointer transition-colors flex items-center gap-1.5 ${
                activeTab === 'register' 
                  ? 'bg-indigo-50 text-indigo-700' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <UserPlus className="w-4 h-4" />
              Ficha do Hóspede (Simulação)
            </button>
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-2 rounded-lg cursor-pointer transition-colors flex items-center gap-1.5 ${
                activeTab === 'guide' 
                  ? 'bg-indigo-50 text-indigo-700' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              Guia & LGPD Policy
            </button>
          </nav>

          {/* Right Area: Notification Feed Icon & Simulated Link Indicator */}
          <div className="flex items-center gap-3">
            
            {/* Live Indicator simulating restricted portal keys */}
            <div className="hidden sm:flex items-center gap-1 bg-emerald-50 text-emerald-800 text-[10px] uppercase font-bold px-3 py-1 rounded-full border border-emerald-100">
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              Agência & Hotel Licenciados
            </div>

            {/* Notification Bell Control */}
            <div className="relative">
              <button
                onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
                className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-colors relative cursor-pointer"
                id="bell-icon-trigger"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifCount > 0 && (
                  <span className="absolute top-1 right-1 bg-rose-600 text-white font-extrabold text-[9px] w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                    {unreadNotifCount}
                  </span>
                )}
              </button>

              {/* Notification feed drop box */}
              {showNotificationsDropdown && (
                <div className="absolute right-0 mt-2 w-80 bg-white border border-slate-200 rounded-xl shadow-lg py-2 z-50 text-xs" id="notifications-dropdown">
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between font-bold text-slate-700">
                    <span>Avisos Importantes do Grupo</span>
                    {unreadNotifCount > 0 && (
                      <button 
                        onClick={handleMarkAllNotificationsRead}
                        className="text-[10px] text-indigo-600 hover:underline cursor-pointer"
                      >
                        Marcar lidas
                      </button>
                    )}
                  </div>
                  
                  <div className="max-h-64 overflow-y-auto divide-y divide-slate-150">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-slate-400">Nenhum aviso ativo.</div>
                    ) : (
                      notifications.map(notif => (
                        <div key={notif.id} className={`p-3 relative hover:bg-slate-50 transition-colors ${!notif.read ? 'bg-indigo-50/20' : ''}`} id={`notif-card-${notif.id}`}>
                          <button
                            onClick={() => handleDismissNotification(notif.id)}
                            className="absolute top-3 right-3 text-slate-300 hover:text-slate-500 cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                          <div className="font-bold text-slate-800 pr-5 flex items-center gap-1.5">
                            {notif.type === 'danger' && <span className="w-1.5 h-1.5 bg-rose-600 rounded-full shrink-0" />}
                            {notif.type === 'warning' && <span className="w-1.5 h-1.5 bg-amber-500 rounded-full shrink-0" />}
                            {notif.type === 'success' && <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full shrink-0" />}
                            {notif.title}
                          </div>
                          <p className="text-slate-500 mt-1 leading-snug">{notif.message}</p>
                          <span className="text-[9px] text-slate-350 block mt-1.5">
                            {new Date(notif.date).toLocaleTimeString('pt-BR')} (Hoje)
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Tabs */}
      <div className="md:hidden bg-white border-b border-slate-150 sticky top-16 z-30 flex justify-around text-[11px] font-bold py-2" id="mobile-navigation-bar">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`py-1 px-3.5 rounded-full ${activeTab === 'dashboard' ? 'bg-indigo-600 text-white' : 'text-slate-600'}`}
        >
          Painel
        </button>
        <button
          onClick={() => setActiveTab('map')}
          className={`py-1 px-3.5 rounded-full ${activeTab === 'map' ? 'bg-indigo-600 text-white' : 'text-slate-600'}`}
        >
          Quartos
        </button>
        <button
          onClick={() => setActiveTab('register')}
          className={`py-1 px-3.5 rounded-full ${activeTab === 'register' ? 'bg-indigo-600 text-white' : 'text-slate-600'}`}
        >
          Ficha / Fólio
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`py-1 px-3.5 rounded-full ${activeTab === 'guide' ? 'bg-indigo-600 text-white' : 'text-slate-600'}`}
        >
          Guia LGPD
        </button>
      </div>

      {/* Core Component Workstation rendering based on activeTab */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8" id="application-body">
        
        {activeTab === 'dashboard' && (
          <GroupDashboard 
            groups={groups}
            selectedGroupId={selectedGroupId}
            onSelectGroup={setSelectedGroupId}
            onUpdateGroup={handleUpdateGroup}
            notifications={notifications}
            onDismissNotification={handleDismissNotification}
          />
        )}

        {activeTab === 'map' && (
          <RoomingMindMap 
            group={currentGroup}
            onUpdateGroup={handleUpdateGroup}
          />
        )}

        {activeTab === 'register' && (
          <div className="max-w-4xl mx-auto space-y-6" id="guest-form-tab-panel">
            <div className="bg-amber-100 border border-amber-200 text-amber-950 rounded-xl p-4 text-xs font-semibold">
              💡 <strong>Interface de Simulação do Hóspede:</strong> Este ambiente simula a tela segura que o hóspede recebe no WhatsApp/Email. Para experimentar o fluxo, selecione o grupo abaixo na chave e utilize a senha respectiva (para <strong>{currentGroup.name}</strong> a senha é <span className="font-mono bg-white px-1.5 py-0.5 rounded border">{currentGroup.groupPassword}</span>).
            </div>

            <GuestForm 
              initialGroupCode={currentGroup.accessHash}
              initialGroupPassword={currentGroup.groupPassword}
              onGuestRegistered={handleGuestRegistered}
              availableGroupAccessCodes={groups.map(g => ({ code: g.accessHash, name: g.name }))}
            />
          </div>
        )}

        {activeTab === 'guide' && (
          <UsageGuide />
        )}

      </main>

      {/* Humble, literal footer conforming with Anti-AI Slop guidelines */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-8 border-t border-slate-800" id="main-app-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <span className="font-bold text-slate-200 block">Gestor de Rooming List • Proteção LGPD Integral</span>
            <span className="text-[10px] text-slate-500 mt-0.5 block">Portal de Apoio para Agências de Turismo e Empreendimentos Hoteleiros.</span>
          </div>

          <div className="text-[11px] text-slate-500">
            Tempo do Servidor: <span className="font-mono text-slate-400">2026-06-16 17:02 UTC</span> • Conforme Lei Federal Nº 13.709/2018 (LGPD).
          </div>
        </div>
      </footer>
    </div>
  );
}
