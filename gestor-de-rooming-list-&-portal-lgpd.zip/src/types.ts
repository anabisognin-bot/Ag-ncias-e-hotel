export interface Guest {
  id: string;
  name: string;
  document: string;
  contact: string;
  age: number;
  country: string;
  address: string;
  needsSpecialRoom: boolean;
  specialRoomDetails?: string;
  needsCrib: boolean;
  foodRestrictions: string; // "Nenhuma", "Vegetariano", "Vegano", "Sem Glúten", "Sem Lactose", "Outra"
  foodRestrictionsDetails?: string;
  languageHelp: string; // "Nenhum", "Inglês", "Espanhol", "Libras", "Outro"
  needsElderlyTechSupport: boolean;
  lgpdConsentGiven: boolean;
  lgpdConsentDate?: string;
  roomId?: string; // Assigned room ID
  errors: string[]; // Missing items or alerts
}

export interface Room {
  id: string;
  number: string;
  type: 'Duplo' | 'Triplo' | 'Casal' | 'Individual';
  capacity: number;
  accessibilityFriendly: boolean;
  hasCrib: boolean;
  guestIds: string[];
}

export interface Group {
  id: string;
  name: string;
  agencyName: string;
  hotelName: string;
  checkInDate: string;
  checkOutDate: string;
  groupPassword?: string;
  accessHash: string; // for the guest URL link
  guests: Guest[];
  rooms: Room[];
}

export interface SystemNotification {
  id: string;
  type: 'warning' | 'info' | 'success' | 'danger';
  title: string;
  message: string;
  date: string;
  read: boolean;
}
