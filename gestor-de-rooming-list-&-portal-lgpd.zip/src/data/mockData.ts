import { Group, SystemNotification } from '../types';

export const mockGroups: Group[] = [
  {
    id: 'grp_001',
    name: 'Excursão Melhor Idade - Gramado & Canela',
    agencyName: 'Agência de Turismo Vento Sul',
    hotelName: 'Hotel Solar Imperial',
    checkInDate: (() => {
      // Set checkInDate to exactly 8 days from now so it displays a vital 8-days-to-go warning (very close to 7-day limit)
      const d = new Date();
      d.setDate(d.getDate() + 8);
      return d.toISOString().split('T')[0];
    })(),
    checkOutDate: (() => {
      const d = new Date();
      d.setDate(d.getDate() + 13);
      return d.toISOString().split('T')[0];
    })(),
    groupPassword: 'canela2026',
    accessHash: 'imp-vento-001',
    guests: [
      {
        id: 'gst_101',
        name: 'Maria de Lourdes Silva',
        document: '32.456.987-X',
        contact: '(51) 98765-4321',
        age: 74,
        country: 'Brasil',
        address: 'Av. Ipiranga, 450 - Porto Alegre, RS',
        needsSpecialRoom: true,
        specialRoomDetails: 'Necessidade de barra de apoio no banheiro e andar baixo (sem elevador longo)',
        needsCrib: false,
        foodRestrictions: 'Sem Lactose',
        foodRestrictionsDetails: 'Intolerância moderada a leite de vaca e derivados',
        languageHelp: 'Nenhum',
        needsElderlyTechSupport: true,
        lgpdConsentGiven: true,
        lgpdConsentDate: '2026-06-10T14:30:00Z',
        roomId: 'room_101',
        errors: []
      },
      {
        id: 'gst_102',
        name: 'José Ribeiro Mendes',
        document: '', // Leaving empty for missing info warning!
        contact: '(11) 99822-1111',
        age: 68,
        country: 'Brasil',
        address: 'Rua Bela Cintra, 1200 - São Paulo, SP',
        needsSpecialRoom: false,
        needsCrib: false,
        foodRestrictions: 'Vegetariano',
        foodRestrictionsDetails: 'Não consome carnes vermelhas nem aves',
        languageHelp: 'Inglês', // wants help but can speak some
        needsElderlyTechSupport: true,
        lgpdConsentGiven: true,
        lgpdConsentDate: '2026-06-11T10:15:00Z',
        roomId: 'room_101',
        errors: ['Documento não preenchido']
      },
      {
        id: 'gst_103',
        name: 'Arnaldo Antunes Filho',
        document: '12.876.321-4',
        contact: '', // Missing contact
        age: 81,
        country: 'Brasil',
        address: 'Rua das Flores, 88 - Canoas, RS',
        needsSpecialRoom: false,
        needsCrib: false,
        foodRestrictions: 'Nenhuma',
        languageHelp: 'Espanhol',
        needsElderlyTechSupport: true,
        lgpdConsentGiven: true,
        lgpdConsentDate: '2026-06-12T09:00:00Z',
        roomId: 'room_102',
        errors: ['Contato não preenchido']
      },
      {
        id: 'gst_104',
        name: 'Ana Maria Antunes',
        document: '9.432.112-9',
        contact: '(51) 99344-5555',
        age: 78,
        country: 'Brasil',
        address: 'Rua das Flores, 88 - Canoas, RS',
        needsSpecialRoom: false,
        needsCrib: false,
        foodRestrictions: 'Sem Glúten',
        foodRestrictionsDetails: 'Doença Celíaca severa. Contaminação cruzada deve ser evitada.',
        languageHelp: 'Nenhum',
        needsElderlyTechSupport: true,
        lgpdConsentGiven: true,
        lgpdConsentDate: '2026-06-12T09:10:00Z',
        roomId: 'room_102',
        errors: []
      },
      {
        id: 'gst_105',
        name: 'Mariana Medeiros',
        document: 'MG-15.987.210',
        contact: '(31) 98877-6655',
        age: 34,
        country: 'Brasil',
        address: 'Av. Afonso Pena, 2030 - Belo Horizonte, MG',
        needsSpecialRoom: false,
        needsCrib: true, // Needs crib
        foodRestrictions: 'Outra',
        foodRestrictionsDetails: '', // Missing food details!
        languageHelp: 'Nenhum',
        needsElderlyTechSupport: false,
        lgpdConsentGiven: false, // LGPD Consent not yet given!
        roomId: '', // Unassigned room
        errors: ['Pendente consentimento LGPD', 'Detalhes da restrição alimentar não especificados', 'Não associado a nenhum quarto']
      }
    ],
    rooms: [
      {
        id: 'room_101',
        number: '101',
        type: 'Duplo',
        capacity: 2,
        accessibilityFriendly: true,
        hasCrib: false,
        guestIds: ['gst_101', 'gst_102']
      },
      {
        id: 'room_102',
        number: '102',
        type: 'Duplo',
        capacity: 2,
        accessibilityFriendly: false,
        hasCrib: false,
        guestIds: ['gst_103', 'gst_104']
      },
      {
        id: 'room_103',
        number: '103',
        type: 'Triplo',
        capacity: 3,
        accessibilityFriendly: true,
        hasCrib: true,
        guestIds: []
      },
      {
        id: 'room_104',
        number: '104',
        type: 'Casal',
        capacity: 2,
        accessibilityFriendly: false,
        hasCrib: false,
        guestIds: []
      }
    ]
  },
  {
    id: 'grp_002',
    name: 'Grupo Executivo TI Segura - CyberSecurity',
    agencyName: 'Corporate Travel Solutions',
    hotelName: 'Grand Hyatt Executive',
    checkInDate: (() => {
      // Set to 5 days, already past the 7 days limit! Emergency warning!
      const d = new Date();
      d.setDate(d.getDate() + 5);
      return d.toISOString().split('T')[0];
    })(),
    checkOutDate: (() => {
      const d = new Date();
      d.setDate(d.getDate() + 8);
      return d.toISOString().split('T')[0];
    })(),
    groupPassword: 'cybersecret',
    accessHash: 'gt-sec-002',
    guests: [
      {
        id: 'gst_201',
        name: 'Roberto D\'Ávila',
        document: '21.098.765-4',
        contact: '(11) 97766-3322',
        age: 45,
        country: 'Brasil',
        address: 'Al. Lorena, 340 - São Paulo, SP',
        needsSpecialRoom: false,
        needsCrib: false,
        foodRestrictions: 'Vegetariano',
        foodRestrictionsDetails: 'Sem frutos do mar, prefere ovolactovegetariano',
        languageHelp: 'Inglês',
        needsElderlyTechSupport: false,
        lgpdConsentGiven: true,
        lgpdConsentDate: '2026-06-14T08:00:00Z',
        roomId: 'room_201',
        errors: []
      },
      {
        id: 'gst_202',
        name: 'Alice Johnson',
        document: 'US-PASS-9876543',
        contact: '+1 (555) 019-2834',
        age: 29,
        country: 'Estados Unidos',
        address: '5th Avenue, New York, NY',
        needsSpecialRoom: false,
        needsCrib: false,
        foodRestrictions: 'Nenhuma',
        languageHelp: 'Espanhol',
        needsElderlyTechSupport: false,
        lgpdConsentGiven: true,
        lgpdConsentDate: '2026-06-14T09:30:00Z',
        roomId: 'room_201',
        errors: []
      }
    ],
    rooms: [
      {
        id: 'room_201',
        number: '201',
        type: 'Duplo',
        capacity: 2,
        accessibilityFriendly: false,
        hasCrib: false,
        guestIds: ['gst_201', 'gst_202']
      }
    ]
  }
];

export const mockNotifications: SystemNotification[] = [
  {
    id: 'not_001',
    type: 'danger',
    title: 'Prazo Limite Excedido (Grupo CyberSecurity)',
    message: 'O prazo de 7 dias para envio do Rooming List final foi atingido. Falta alocação de quartos para novos membros.',
    date: '2026-06-16T12:00:00Z',
    read: false
  },
  {
    id: 'not_002',
    type: 'warning',
    title: 'Informações pendentes: Mariana Medeiros',
    message: 'Hóspede está com restrição alimentar "Outra" sem detalhes e não possui consentimento LGPD assinado.',
    date: '2026-06-16T15:30:00Z',
    read: false
  },
  {
    id: 'not_003',
    type: 'info',
    title: 'Guia de Proteção de Dados (LGPD)',
    message: 'Lembre-se: os dados sensíveis de restrição alimentar e acessibilidade só devem ser utilizados para garantir a segurança e o conforto do cliente durante a estadia.',
    date: '2026-06-16T16:00:00Z',
    read: true
  }
];
